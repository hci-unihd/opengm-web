function evaluation_default(dataset) 
    setup;
    [res,names] = evaluation_load(dataset);
    algs = fieldnames(res);
    numberOfInstances = numel(res.(algs{1}).times);
    
    data.T = zeros(numel(algs),numberOfInstances);
    data.V = zeros(numel(algs),numberOfInstances);
    data.VE = zeros(numel(algs),numberOfInstances);
    data.B = zeros(numel(algs),numberOfInstances);
    
    for a=1:numel(algs)
       alg = algs{a};
       for i=1:numberOfInstances
            data.T(a,i) = max(res.(alg).times{i});
            data.V(a,i) = min(res.(alg).values{i});
            data.VE(a,i) = res.(alg).values{i}(end);
            data.B(a,i) = max(res.(alg).bounds{i});
       end       
    end
    
    data.MT  = mean(data.T,2);
    data.MV  = mean(data.V,2);
    data.MVE = mean(data.VE,2);
    data.MB  = mean(data.B,2);
    if numel(algs)==1
        data.best = 1; 
        data.bestB = 1;
    else
        %data.best  = mean(abs(data.VE-ones(numel(algs),1)*min(data.VE))<10^-5,2);% ./abs(ones(numel(algs),1)*min(data.VE))<abs(ones(numel(algs),1)*min(data.VE))*10^-10,2);
        %data.bestB = mean(abs(data.B-ones(numel(algs),1)*max(data.B))<10^-5,2);% ./abs(ones(numel(algs),1)*max(data.B))<abs(ones(numel(algs),1)*max(data.B))*10^-10,2);
     
        data.best  = mean(abs(data.VE-ones(numel(algs),1)*min(data.VE))<abs(10^-8*ones(numel(algs),1)*min(data.VE)),2);% ./abs(ones(numel(algs),1)*min(data.VE))<abs(ones(numel(algs),1)*min(data.VE))*10^-10,2);
        data.bestB = mean(abs(data.B-ones(numel(algs),1)*max(data.B))<abs(10^-8*ones(numel(algs),1)*max(data.B)),2);% ./abs(ones(numel(algs),1)*max(data.B))<abs(ones(numel(algs),1)*max(data.B))*10^-10,2);
    end
    data.opt = mean((data.VE-data.B)./abs(data.VE)<10^-8,2);
    
    saveShortTable(data, [tabelpath,'small/',dataset,'.tex'], algs, dataset,'scriptsize');
    saveShortTable(data, [tabelpath,'small2/',dataset,'.tex'], algs, dataset,'small');
    saveLargeTable(data, [tabelpath,'large/',dataset,'.tex'], algs, dataset,names); 
%     disp([ sprintf('%20s','algorithm'),' & ',...
%            sprintf('%13s','mean run time'),'     & ',...
%            sprintf('%13s','mean value'),' & ',...
%            sprintf('%13s','mean bound'),' & ',...
%            sprintf('%8s','best'), ' \\']);   
%     for a =1:numel(algs)
%         disp([sprintf('%20s',algs{a}),' & ',...
%               sprintf('%13s',num2str(MT(a),'% 10.2f')),' sec & ', ...
%               sprintf('%13s',num2str(MVE(a),'% 10.2f')),' & ', ...
%               sprintf('%13s',num2str(MB(a),'% 10.2f')),'&', ...
%               sprintf('%8s',num2str(best(a)*100,'% 3.2f')),' \% \\']);     
%     end
end

function alg = algName(algIn)
    alg = strrep(algIn,'_','-'); 
    if(strcmp(alg,'opengm-ddbundle')), alg = 'opengm-ddbundleA'; end;
    if(strcmp(alg,'opengm-ddhbundle')), alg = 'opengm-ddhbundleA'; end;
    alg = strrep(alg,'-TL',''); 
    alg = strrep(alg,'-TABLES','');
    alg = strrep(alg,'expansion','expan');
    alg = strrep(alg,'opengm','ogm');
    alg = strrep(alg,'ddbundle','bundle');
    alg = strrep(alg,'ddsubgrad','subgrad');
end

function saveShortTable(data, file, algs, dataset, textsize)
    if(~isempty(file))
        fid = fopen(file, 'w'); 
        fprintf(fid,['\\begin{table}[H]\\',textsize,'\n\\begin{tabular}{l|rrrrr}\n']);
    end;
    text = [ sprintf('%20s','algorithm'),' & ',...
             sprintf('%13s','mean run time'),'     & ',...
             sprintf('%13s','mean value'),' & ',...
             sprintf('%13s','mean bound'),' & ',...
             sprintf('%8s','best'),' & ',...
             sprintf('%8s','ver. opt'), '   '];
    if(~isempty(file)),     
        fprintf(fid,[text,'\\\\ \\hline \n']);
    else
        disp(text);
    end
    for a =1:numel(algs)
        text = [ sprintf('%20s',algName(algs{a})),' & ',...
                 sprintf('%13s',num2str(data.MT(a),'% 10.2f')),' sec & ', ...
                 sprintf('%13s',num2str(data.MVE(a),'% 10.2f')),' & ', ...
                 sprintf('%13s',num2str(data.MB(a),'% 10.2f')),' & ', ...
                 sprintf('%8s',num2str(data.best(a)*100,'% 3.2f')),' & ', ...
                 sprintf('%8s',num2str(data.opt(a)*100,'% 3.2f')),' ']; 
        if(~isempty(file)), 
            fprintf(fid,[text,'\\\\ \n']);
        else
            disp(text);
        end    
    end
    if(~isempty(file))
        fprintf(fid,['\\end{tabular}\n\\caption{caption-smalltable-',dataset,'}\n\\label{tab:smalltable-',dataset,'}\n\\end{table}']);
        fclose(fid);
    end;
end



function saveLargeTable(data, file, algs, dataset,names) 
    EPS = 10^-10;
    fid = fopen(file, 'w'); 
    table = '{\\tiny\\begin{longtable}{|l|'; 
    for i=1:numel(algs)
        table=[table,'r|'];
    end
    table = [table,'}']; 
    fprintf(fid,[table,' \n']); 
    fprintf(fid,['\\caption[]{tab',dataset,'}\n\\\\\\hline\n']);
  
    
    table=['\\textbf{',dataset,'}'];
    for i=1:numel(algs)
        table=[table,'& ',algName(algs{i})];
    end
   
    fprintf(fid,[table,'\\\\\\hline\n']);
    fprintf(fid,'\\endfirsthead\n'); 
    fprintf(fid,['\\hline\n',table,'\\\\\\hline\n']); 
    fprintf(fid,'\\endhead\n');
    
    table=''; 
    BV = (data.VE-ones(size(data.VE,1),1)*min(data.VE))<10^-5; %ones(size(data.VE,1),1)*abs(min(data.VE,1))*EPS;
    BB = (ones(size(data.B,1),1)*max(data.B)-data.B)<10^-5;    %abs(ones(size(data.B,1),1)*max(data.B,1))*EPS;
    
  
    for m=1:size(data.V,2)
        table = [table,strrep(names{m},'_','\\_')];
        for a=1:numel(algs)
            if(BV(a,m)) %(data.VE(a,m)-min(data.VE(:,m)))/abs(min(data.VE(:,m)))<EPS)
                table=[table,'& \\bf ',num2str(data.VE(a,m),'%4.2f')];
            else
                table=[table,'& ',num2str(data.VE(a,m),'%4.2f')];
            end
        end
        table = [table,'\\\\\\nopagebreak\n'];
        fprintf(fid,table); table='';
        for a=1:numel(algs) 
            if(BB(a,m)) %(max(data.B(:,m))-data.B(a,m))/abs(max(data.B(:,m)))<EPS)
                table=[table,'& \\bf ',num2str(data.B(a,m),'%4.2f')];
            else
                table=[table,'& ',num2str(data.B(a,m),'%4.2f')];
            end
        end
        table = [table,'\\\\\\nopagebreak\n']; 
        fprintf(fid,table); table='';
        for a=1:numel(algs)
            table=[table,'& ',num2str(data.T(a,m),'%4.2f')];    
        end
        table = [table,'\\\\\\hline\n'];
        fprintf(fid,table); table='';
    end   
    
     %Mean Energy
    fprintf(fid,'\\hline\n');
    fprintf(fid,table); table=['\\textbf{mean energy}'];
    for a=1:numel(algs) 
        table=[table,'& ',num2str(data.MV(a),'%4.2f')];
    end
    table = [table,'\\\\\\hline\n'];
    fprintf(fid,table); table='';   
    %Mean Bound 
    fprintf(fid,table); table=['\\textbf{mean bound}'];
    for a=1:numel(algs)
       table=[table,'& ',num2str(data.MB(a),'%4.2f')];
    end
    table = [table,'\\\\\\hline\n'];
    fprintf(fid,table); table=''; 
    %Mean Runtime 
    fprintf(fid,table); table=['\\textbf{mean runtime}'];
    for a=1:numel(algs)
       table=[table,'& ',num2str(data.MT(a),'%4.2f')];
    end
    table = [table,'\\\\\\hline\n'];
    fprintf(fid,table); table='';  
    %Precentage best value 
    table=['\\textbf{best value}'];
    for a=1:numel(algs)
       table=[table,'& ',num2str(data.best(a)*100,'%4.2f'),''];
    end
    table = [table,'\\\\\\hline\n'];
    fprintf(fid,table); table=''; 
     %Precentage best bound 
    table=['\\textbf{best bound}'];
    for a=1:numel(algs)
       table=[table,'& ',num2str(data.bestB(a)*100,'%4.2f'),''];
    end
    table = [table,'\\\\\\hline\n'];
    fprintf(fid,table); table=''; 
    %Precentage guranteed optimum 
    table=['\\textbf{verified opt}'];
    for a=1:numel(algs)
       table=[table,'& ',num2str(data.opt(a)*100,'%4.2f'),''];
    end
    table = [table,'\\\\\\hline\n'];
    fprintf(fid,table); table='';
    

    fprintf(fid,'\\end{longtable}}');
    fclose(fid);
      
end