%%
% This file includes the paths used during evaluation 
% of the graphical model benchmark (GMB)
%%

% main benchmark directory (setting this should be sufficient)
global gmb_mainpath;
gmb_mainpath   = '/net/gorgonzola/storage/jkappes/gm-benchmark-final/';

% path to the result-files
global gmb_resultpath;
gmb_resultpath = [gmb_mainpath,'results/'];

% path to the model-files
global gmb_modelpath;
gmb_modelpath  = [gmb_mainpath,'models/'];

% path to data used for evaluation
global gmb_datapath;
gmb_datapath   = [gmb_mainpath,'data/'];

% path to the main script directory
global gmb_scriptpath
gmb_scriptpath = [gmb_mainpath,'scripts/'];

% path to the directory where latex-tables should be stored
global gmb_latextablepath;
gmb_latextablepath  = [gmb_mainpath,'latextables/'];

% path to the directory where html-tables should be stored
global gmb_htmltablepath;
gmb_htmltablepath  = [gmb_mainpath,'htmltables/'];

% path to the directory where plots should be stored
global gmb_plotpath;
gmb_plotpath   = [gmb_mainpath,'plots/'];

% path to the directory where javascript-plot-data should be stored
global gmb_jsplotpath;
gmb_jsplotpath   = [gmb_mainpath,'jsplots/'];