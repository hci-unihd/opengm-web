function [res,names] = evaluation_load(dataset, evalGTflag)  
    global gmb_modelpath;
    global gmb_resultpath;
    disp(['* Start prozessing ',gmb_resultpath,dataset,' ...']);
    
    res               = struct;
    numberOfInstances = 0;
    names             = cell(0,1);
    
    %% Check if names of instances are stored in modelinfo
    % if load them from mat-file
    % else generate them and store them to mat-file
    %
    % this modelinfo-files can be used to exlude models from evaluation!
    if(exist(['model-info/',dataset,'.mat']))
        temp = load(['model-info/',dataset,'.mat']);
        names = temp.names;
        numberOfInstances = numel(temp.names); 
    else
        m = dir([gmb_modelpath,dataset,'/*.h5']);
        for i=1:numel(m)
            if m(i).isdir(), continue; end;
            numberOfInstances = numberOfInstances+1;
        end
        names = cell(numberOfInstances,1);
        for i=1:numel(m)
            names{i} = m(i).name(1:end-3);
        end
        save([gmb_modelpath,dataset,'.mat'],'names');
    end
    disp(['*** Found ',num2str(numberOfInstances),' instances.']);
    
    %% find algorithms for this dataset  
    t = dir([gmb_resultpath,dataset]);
    algs = cell(0,1);
    for i=1:numel(t)
        if(t(i).name(1)~='.')
            algs{end+1} = t(i).name;
        end
    end
    disp(['*** Found ',num2str(numel(algs)),' algorithms.']);
    fprintf(['* -> Start loading result files ... ']);
    infotext = ['0/',num2str(numel(algs))];
    fprintf(infotext);
    %% Evaluate algorithms for this dataset
    for a=1:min(100000,numel(algs))
        res.(algs{a}).times  = cell(1,numberOfInstances);
        res.(algs{a}).values = cell(1,numberOfInstances);
        res.(algs{a}).bounds = cell(1,numberOfInstances);
        res.(algs{a}).states = cell(1,numberOfInstances);
        for i=1:numberOfInstances
            file = [gmb_resultpath,dataset,'/',algs{a},'/',names{i},'.h5'];
            if(exist(file))
                res.(algs{a}).times{i}   = h5read(file,'/times');
                res.(algs{a}).values{i}  = h5read(file,'/values');
                res.(algs{a}).bounds{i}  = h5read(file,'/bounds');
                res.(algs{a}).states{i}  = h5read(file,'/states');
            else
                res.(algs{a}).times{i}   = nan;
                res.(algs{a}).values{i}  = nan;
                res.(algs{a}).bounds{i}  = nan;
                res.(algs{a}).states{i}  = nan;    
            end
        end
        fprintf( repmat('\b',1,length(infotext)) );
        infotext = [num2str(a),'/',num2str(numel(algs))];
        fprintf(infotext);     
    end 
    fprintf('\n');
  
    % if ground thruth should be evaluated and evaluation-script is
    % available run evaluation on ground truth.
    if(evalGTflag && exist(['quality-evaluation/',strrep(dataset,'-','_'),'.m']))
        disp('x');
        tmppath=path;
        addpath('quality-evaluation');
        eval( [strrep(dataset,'-','_')] ); 
        path(tmppath);
    end
end
