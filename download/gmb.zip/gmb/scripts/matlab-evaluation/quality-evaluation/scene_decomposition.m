

% Evaluation for DAGS semantic scene segmentation instances
%
% Author: Sebastian Nowozin <Sebastian.Nowozin@microsoft.com>
% Date: 30th October 2012

% TODO: adjust this path to where you unpacked EnergyMinimizationDAGS
dags_path = '~/data/EnergyMinimizationDAGS';
addpath(sprintf('%s/code', dags_path));

for a=1:numel(fieldnames(res))
	fn = fieldnames(res);
	alg = fn{a};
	for i=1:numberOfInstances
        modelname = names{i};

		% Load ground truth map
		gt_image = load(sprintf('%s/data/%s-gt.mat', dags_path, modelname));
		gt_image = gt_image.gt_image;

		% Form pixel-level output
		spix=load(sprintf('%s/data/%s-spix.mat', dags_path, modelname));
		spix=spix.spix_image;
		x = res.(alg).states{i};
		x = x + 1;
		M_map=create_labeling(x, spix);

		% Compute pixel level correctness, between 0 (everything wrong) to 1
		% (all pixels labelled correctly).
		correct_map = double(M_map == gt_image);
		res.(alg).PixelAccuracy{i} = mean(correct_map(:));
	end
end
