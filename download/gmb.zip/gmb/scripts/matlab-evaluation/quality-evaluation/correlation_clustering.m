gt_img = dir([datapath,'correlation-clustering/GroundTruth/*.mat']);
gt_imsegs = dir([datapath,'correlation-clustering/superpixels/*.mat']);

for a=1:numel(fieldnames(res))
    fn = fieldnames(res);
    alg = fn{a};
    sumPRI = 0;
    sumGCE = 0;
    sumVOI = 0;
    sumSCO = 0;
    sumBDE = 0;
    for i=1:numberOfInstances
        i
        load([datapath,'correlation-clustering/GroundTruth/',gt_img(i).name], 'gt_seg');
        load([datapath,'correlation-clustering/superpixels/',gt_imsegs(i).name], 'imsegs');
        partitions = zeros(size(imsegs.segimage));
        nsp = imsegs.nseg;
        for sp=1:nsp
            partitions(imsegs.segimage == sp) = res.(alg).states{i}(sp);
        end
        curSCO = compute_covering(partitions, gt_seg);
        [curPRI,curGCE,curVOI] = compare_segmentations(partitions,gt_seg);
        curBDE = compare_image_boundary_error(gt_seg, partitions);
        
        res.(alg).SCO{i} =  curSCO;
        res.(alg).PRI{i} =  curPRI;
        res.(alg).GCE{i} =  curGCE;
        res.(alg).VOI{i} =  curVOI;
        res.(alg).BDE{i} =  curBDE;
        
        sumPRI = sumPRI + curPRI;
        sumGCE = sumGCE + curGCE;
        sumVOI = sumVOI + curVOI;
        sumSCO = sumSCO + curSCO;
        sumBDE = sumBDE + curBDE;
    end
    res.(alg).AvrPRI = sumPRI/numberOfInstances;
    res.(alg).AvrGCE = sumGCE/numberOfInstances;
    res.(alg).AvrVOI = sumVOI/numberOfInstances;
    res.(alg).AvrSCO = sumSCO/numberOfInstances;
    res.(alg).AvrBDE = sumBDE/numberOfInstances;
    
end