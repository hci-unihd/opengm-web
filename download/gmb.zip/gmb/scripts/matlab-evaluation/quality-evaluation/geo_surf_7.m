

% Evaluation for Geometric Labelling task (with 7 labels)
%
% Author: Dhruv Batra (dbatra -at- {ttic.edu,vt.edu})
% Date: 5th November 2012

% load ground-truth and superpixel information
load(fullfile(datapath,'geo-surf/allimsegs.mat'));


for a=1:numel(fieldnames(res))
	fn = fieldnames(res);
	alg = fn{a};
	for i=1:numberOfInstances
        modelname = names{i};
        N = str2num(modelname(3:end));

		% Form pixel-level output
		x = res.(alg).states{i};
		x = x + 1;
       
        assert(imsegs(N).nseg == numel(x));
        
		M_map=zeros(imsegs(N).imsize);
        gt_image = zeros(imsegs(N).imsize);
        for psp = 1:imsegs(N).nseg
            inds = find(imsegs(N).segimage==psp);
            M_map(inds) = x(psp);

            label = imsegs(N).labels(psp);
            gt_image(inds) = label;
        end
        
		% Compute pixel level correctness, between 0 (everything wrong) to 1
		% (all pixels labelled correctly).
		correct_map = double(M_map == gt_image);
		res.(alg).PixelAccuracy{i} = mean(correct_map(:));
	end
end
