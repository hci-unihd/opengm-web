clear all
close all
clc


%%
datasets = {'mc3d1', 'mc3d2'};
optimizers = {'opengm_mc', 'opengm_mc_fdo', 'opengm_mc6'};
for n = 1:numel(datasets)
    seg_supervoxel = marray_load(['../data/seg-3d/' datasets{n} '-data.h5'], 'segmentation-initial');
    seg_true = marray_load(['../data/seg-3d/' datasets{n} '-data.h5'], 'segmentation-true');
    for m = 1:numel(optimizers)
        result_opengm = marray_load(['../results/seg-3d/' optimizers{m} '/' datasets{n} '-model.h5'], 'states');
        result_opengm = uint32(result_opengm);

        % relabel segments
        seg_opengm = result_opengm(seg_supervoxel) + 1;
        %{
        for j = 1:numel(seg_opengm)
            seg_opengm(j) = result_opengm(seg_opengm(j)) + 1;
        end
        %}

        vi = andres_variation_of_information(seg_true, seg_opengm);
        ri = andres_rand_index(seg_true, seg_opengm);
        fprintf('data=%s, optimizer=%s, vi=%f, ri=%f\n', datasets{n}, optimizers{m}, vi, ri);
    end
end
