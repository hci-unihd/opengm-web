clear all
close all
clc


%% parameters
% optimizer output
gm_labels_folder_name = './data/opengm2-solver-output';
gm_labels_dataset_name = 'states';
% superpixel segmentations
superpixel_folder_name = './data/superpixel-segmentations';
% ground truth
bsd300_h5_folder_name = './data/bsd300-h5';


%% evaluation
truth_folder_name = [bsd300_h5_folder_name '/human/color'];
segmentor_names = dir(truth_folder_name);
segmentor_names = segmentor_names(3:end); % remove . and ..
vi = zeros(10000, 1);
ri = zeros(10000, 1);
counter = 0;
for j = 1:numel(segmentor_names) % loop over human segmentors
    segmentor_name = segmentor_names(j).name;
    seg_true_names = dir([truth_folder_name '/' segmentor_name]);
    seg_true_names = seg_true_names(3:end); % remove . and ..
    for k = 1:numel(seg_true_names) % loop over images the current segmentor segmented
        seg_true_name = seg_true_names(k).name;
        seg_true_file_name = [truth_folder_name '/' segmentor_name '/' seg_true_name];
        seg_true = marray_load(seg_true_file_name, 'seg');
        
        image_id = seg_true_name(1:end-3); % remove the .h5
        gm_labels_file_name = sprintf('%s/%s.bmp.h5', gm_labels_folder_name, image_id);
        if exist(gm_labels_file_name, 'file') % if a test image (not a training image)
            gm_labels = marray_load(gm_labels_file_name, gm_labels_dataset_name);
            
            superpixel_file_name = sprintf('%s/%s.bmp.h5', superpixel_folder_name, image_id);
            seg_superpixel = marray_load(superpixel_file_name, 'superpixel-segmentation');
            seg_superpixel = seg_superpixel(1:2:end, 1:2:end)';
            
            % re-label superpixel segmentation w.r.t. optimizer output
            seg_auto = seg_superpixel;
            for m = 1 : numel(seg_auto)
                seg_auto(m) = gm_labels(seg_auto(m)) + 1;
            end

            counter = counter + 1;
            vi(counter) = andres_variation_of_information(seg_true, seg_auto);
            ri(counter) = andres_rand_index(seg_true, seg_auto);

            fprintf('img=%s, human=%s, %f, %f\n', image_id, segmentor_name, vi(counter), ri(counter));
            
            %{
            cmap = rand(1000,3);
            figure(1); image(seg_true); colormap(cmap);
            figure(2); image(seg_auto); colormap(cmap);
            waitforbuttonpress;
            %}
        end
    end
end
vi = vi(1:counter);
ri = ri(1:counter);


%% final output
fprintf('mean VI: %f, mean RI: %f\n', mean(vi), mean(ri));

