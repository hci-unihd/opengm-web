	gt = dir([datapath,'matching/*.mat']);
    for a=1:numel(fieldnames(res))
       fn = fieldnames(res);
       alg = fn{a};
       for i=1:numberOfInstances
            sol = load([datapath,'matching/',gt(i).name]);
			diff = sol.tp(1:2,sol.correct_labeling+1) - sol.tp(1:2,double(res.(alg).states{i})+1);
            res.(alg).MeanPositionError{i} = mean(sqrt(sum(diff.^2)));
       end       
    end

