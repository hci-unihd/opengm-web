
    gt = dir([datapath,'mrf-stereo/*.png']);
    for a=1:numel(fieldnames(res))
       fn = fieldnames(res);
       alg = fn{a};
       for i=1:numberOfInstances
            I = imread([datapath,'mrf-stereo/',gt(i).name])';
            res.(alg).HammingDistance{i} =  mean(abs(double(res.(alg).states{i}) - double(I(:))));
       end       
    end