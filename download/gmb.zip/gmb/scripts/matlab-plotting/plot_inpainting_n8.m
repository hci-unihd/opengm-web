function plot_inpainting_n8(alg,model,save)
    addpath('../evaluation');
    dataset = 'inpainting-n8';
    setup
    if(isnumeric(model))
        filepath  = ['../../results/' dataset '/',alg,'/'];
        files     = dir([filepath,'*.h5']);
        modelname = files(model).name(1:end-3);
        file      = [filepath,modelname,'.h5'];    
    else
        modelname = model;
        file      = ['../../results/' dataset '/',alg,'/',model,'.h5'];
    end
    
    x = h5read(file,'/states');
    
    models = {...      
      struct('tag','triplepoint-plain-box',...
             'imgsize', [120 120],...
             'prototypes', max(0,[0.8794   -0.2709    0.3914;
                                  0.3914    0.8794   -0.2709;
                                 -0.2709    0.3914    0.8794;
                                  1.0000    1.0000    1.0000])),...   
      struct('tag','triplepoint-plain-box-inverse',...
             'imgsize', [120 120],...
             'prototypes', max(0,[0.8794   -0.2709    0.3914;
                                  0.3914    0.8794   -0.2709;
                                 -0.2709    0.3914    0.8794;
                                  1.0000    1.0000    1.0000])),...
      struct('tag','triplepoint4-plain-ring',...
             'imgsize', [120 120],...
             'prototypes', max(0,[0.8794   -0.2709    0.3914;
                                  0.3914    0.8794   -0.2709;
                                 -0.2709    0.3914    0.8794;
                                  1.0000    1.0000    1.0000])),...
      struct('tag','triplepoint4-plain-ring-inverse',...
             'imgsize', [120 120],...
             'prototypes', max(0,[0.8794   -0.2709    0.3914;
                                  0.3914    0.8794   -0.2709;
                                 -0.2709    0.3914    0.8794;
                                  1.0000    1.0000    1.0000]))...
             };

    for k = 1:numel(models)
        if strcmp(models{k}.tag, modelname)
            I = uint8(reshape(x,models{k}.imgsize));
            if(save)
                mkdir(['../../result-images/' dataset '/',alg,'/']);
                imwrite(I,models{k}.prototypes, ['../../result-images/' dataset '/',alg,'/',modelname,'.png']);
            else
                imshow(I,models{k}.prototypes);
            end
        end
    end
end
