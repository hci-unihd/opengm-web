function plot_geo_surf_3(alg,model,save)
%PLOT_GEO_SURF_3 -- Visualize result images for geometric labelling with 3
% labels.
%
% Author: Dhruv Batra (dbatra -at- {ttic.edu,vt.edu})
% Date: 5th November 2012


setup

if isnumeric(model)
	filepath = ['../../results/geo-surf-3/',alg,'/'];
	files = dir(sprintf('%s*.h5', filepath));
	modelname = files(model).name;
	file = [filepath,modelname];    
	modelname = strtok(modelname, '.');
    load([datapath,'geo-surf/' modelname '.mat'],'imseg');
else
	modelname = model;
	file = [resultpath,'geo-surf-3/',alg,'/',model,'.h5'];
    load([datapath,'geo-surf/' model '.mat'],'imseg');
end

x = h5read(file,'/states');
x = x + 1;
assert(min(x(:)) >= 1);
assert(max(x(:)) <= 3);

% Form pixel-level output
M_map=zeros(imseg.imsize);
for psp = 1:imseg.nseg
    %inds = find(imseg.segimage==psp);
    M_map(imseg.segimage==psp) = x(psp);
end
map=lines(3);

if save
	mkdir([mainpath,'result-images/geo-surf-3/',alg,'/']);
	imwrite(M_map, map, [mainpath,'result-images/geo-surf-3/',alg, ...
		'/', modelname, '.png'], 'PNG', ...
		'Description', sprintf('MAP solution of algorithm %s on %s', alg, modelname));
else
	imagesc(M_map);
	axis image;
	colormap(map);
	title(sprintf('Image "%s" MAP solution by algorithm "%s"', model, alg));
end


