function plot_scene_decomposition(alg,model,save)
%PLOT_SCENE_DECOMPOSITION -- Visualize result images.
%
% Author: Sebastian Nowozin <Sebastian.Nowozin@microsoft.com>
% Date: 30th October 2012


% TODO: adjust this path to where you unpacked EnergyMinimizationDAGS
%dags_path = 'z:/collab/heidelberg-benchmark/gm-bench/data/EnergyMinimizationDAGS';
dags_path = '/net/hciserver03/storage/jkappes/data/EnergyMinimizationDAGS';

addpath(sprintf('%s/code', dags_path));

setup

if isnumeric(model)
	filepath = ['../../results/scene-decomposition/',alg,'/'];
	files = dir(sprintf('%s*.h5', filepath));
	modelname = files(model).name;
	file = [filepath,modelname];    
	modelname = strtok(modelname, '.');
else
	modelname = model;
	file = ['../../results/mrf-stereo/',alg,'/',model,'.h5'];
end

x = h5read(file,'/states');
x = x + 1;
assert(min(x(:)) >= 1);
assert(max(x(:)) <= 8);

spix=load(sprintf('%s/data/%s-spix.mat', dags_path, modelname));
spix=spix.spix_image;

% Create full-image visualization
M_map=create_labeling(x, spix);
map=dags_colormap();

if save
	mkdir(['../../result-images/scene-decomposition/',alg,'/']);
	imwrite(M_map, map, ['../../result-images/scene-decomposition/',alg, ...
		'/', modelname, '.png'], 'PNG', ...
		'Description', sprintf('MAP solution of algorithm %s on %s', alg, modelname));
else
	imagesc(M_map);
	axis image;
	colormap(map);
	title(sprintf('Image "%s" MAP solution by algorithm "%s"', model, alg));
end


