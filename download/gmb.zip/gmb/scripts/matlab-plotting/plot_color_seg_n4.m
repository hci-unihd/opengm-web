function plot_color_seg_n4(alg,model,save)
    addpath('../evaluation');
    dataset = 'color-seg-n4';
    setup
    if(isnumeric(model))
        filepath  = ['../../results/' dataset '/',alg,'/'];
        files     = dir([filepath,'*.h5']);
        modelname = files(model).name(1:end-3);
        file      = [filepath,modelname,'.h5'];   
    else
        modelname = model;
        file      = ['../../results/' dataset '/',alg,'/',model,'.h5'];
    end
    
    x = h5read(file,'/states');
    
    load('color-seg-details.mat');

    for k = 1:numel(models)
        if strcmp(models{k}.tag, modelname)
            I = uint8(reshape(x,models{k}.dimensions));
            if(save)
                mkdir(['../../result-images/' dataset '/',alg,'/']);
                imwrite(I,models{k}.prototypes, ['../../result-images/' dataset '/',alg,'/',modelname,'.png']);
            else
                imshow(I,models{k}.prototypes);
            end
        end
    end
end
