function plot_geo_surf_7(alg,model,save)
%PLOT_GEO_SURF_7 -- Visualize result images for geometric labelling with 7
% labels.
%
% Author: Dhruv Batra (dbatra -at- {ttic.edu,vt.edu})
% Date: 5th November 2012


setup

if isnumeric(model)
	filepath = ['../../results/geo-surf-7/',alg,'/'];
	files = dir(sprintf('%s*.h5', filepath));
	modelname = files(model).name;
	file = [filepath,modelname];    
	modelname = strtok(modelname, '.');
    load(['../../data/geo-surf/' modelname '.mat'],'imseg');
else
	modelname = model;
	file = ['../../results/geo-surf-7/',alg,'/',model,'.h5'];
    load(['../../data/geo-surf/' model '.mat'],'imseg');
end

x = h5read(file,'/states');
x = x + 1;
assert(min(x(:)) >= 1);
assert(max(x(:)) <= 7);

% Form pixel-level output
M_map=zeros(imseg.imsize);
for psp = 1:imseg.nseg
    %inds = find(imseg.segimage==psp);
    M_map(imseg.segimage==psp) = x(psp);
end
map = lines(7);

if save
	mkdir(['../../result-images/geo-surf-7/',alg,'/']);
	imwrite(M_map, map, ['../../result-images/geo-surf-7/',alg, ...
		'/', modelname, '.png'], 'PNG', ...
		'Description', sprintf('MAP solution of algorithm %s on %s', alg, modelname));
else
	imagesc(M_map);
	axis image;
	colormap(map);
	title(sprintf('Image "%s" MAP solution by algorithm "%s"', model, alg));
end


