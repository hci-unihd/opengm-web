function plot_mrf_photomontage(alg,instance_name,save)

    close all
    iptsetpref('ImshowBorder', 'tight');
    setup

    file = ['../../results/mrf-photomontage/',alg,'/',instance_name,'.h5'];
    
    sol = h5read(file,'/states');
    
    
    if(strcmp(instance_name,'family-gm'))
        % Loading input images
        files = dir([datapath,'mrf-photomontage/family/*.jpg']);
        n_inputs = numel(files);
        imgs = cell(n_inputs,1);
        imgs_r = cell(n_inputs,1);
        imgs_g = cell(n_inputs,1);
        imgs_b = cell(n_inputs,1);
        for n=1:n_inputs
            imgs{n} = imread(sprintf([datapath,'mrf-photomontage/family/',files(n).name]));
            imgs_r{n} = imgs{n}(:,:,1);
            imgs_g{n} = imgs{n}(:,:,2);
            imgs_b{n} = imgs{n}(:,:,3);
        end
        
        % Make result image
        result_r = uint8(zeros(size(imgs{1}(:,:,1))));
        result_g = uint8(zeros(size(imgs{1}(:,:,2))));
        result_b = uint8(zeros(size(imgs{1}(:,:,3))));
        [lenx, leny] = size(result_r);
        xx = reshape(sol, lenx,leny);
        for x=1:lenx
            for y=1:leny
                result_r(x,y) = imgs_r{xx(x,y)+1}(x,y);
                result_g(x,y) = imgs_g{xx(x,y)+1}(x,y);
                result_b(x,y) = imgs_b{xx(x,y)+1}(x,y);
            end
        end
        result(:,:,1) = result_r;
        result(:,:,2) = result_g;
        result(:,:,3) = result_b;
        
        % Show and save result image
        figure;
        imshow(result);
        
        if(save)
            mkdir(['../../result-images/mrf-photomontage/',alg,'/']);
            imwrite(result, ['../../result-images/mrf-photomontage/',alg,'/',instance_name,'.png']);
        end
        
    elseif(strcmp(instance_name,'pano-gm'))
        % Loading input images
        files = dir([datapath,'mrf-photomontage/pano/*.png']);
        n_inputs = numel(files);
        imgs = cell(n_inputs,1);
        imgs_r = cell(n_inputs,1);
        imgs_g = cell(n_inputs,1);
        imgs_b = cell(n_inputs,1);
        for n=1:n_inputs
            imgs{n} = imread(sprintf([datapath,'mrf-photomontage/pano/',files(n).name]));
            imgs_r{n} = imgs{n}(:,:,1);
            imgs_g{n} = imgs{n}(:,:,2);
            imgs_b{n} = imgs{n}(:,:,3);
        end
        
        % Make result image
        result_r = uint8(zeros(size(imgs{1}(:,:,1))));
        result_g = uint8(zeros(size(imgs{1}(:,:,2))));
        result_b = uint8(zeros(size(imgs{1}(:,:,3))));
        [lenx, leny] = size(result_r);
        xx = reshape(sol, lenx,leny);
        for x=1:lenx
            for y=1:leny
                result_r(x,y) = imgs_r{xx(x,y)+1}(x,y);
                result_g(x,y) = imgs_g{xx(x,y)+1}(x,y);
                result_b(x,y) = imgs_b{xx(x,y)+1}(x,y);
            end
        end
        result(:,:,1) = result_r;
        result(:,:,2) = result_g;
        result(:,:,3) = result_b;
        
        % Show and save result image
        figure;
        imshow(result);
        
        if(save)
            mkdir(['../../result-images/mrf-photomontage/',alg,'/']);
            imwrite(result, ['../../result-images/mrf-photomontage/',alg,'/',instance_name,'.png']);
        end
    else
        display('Instance Name is wrong.');
        return;
    end

end