function plot_correlation_clustering(alg,instance_name,save)

    close all
    iptsetpref('ImshowBorder', 'tight');
    setup

    file = ['../../results/correlation-clustering/',alg,'/',instance_name,'.h5'];
    
    x = h5read(file,'/states');
    
    % Ground Truth Loading
    load([datapath,'correlation-clustering/GroundTruth/',instance_name,'.mat'], 'gt_seg');
    
    %  Superpixel Loading
    load([datapath,'correlation-clustering/superpixels/',instance_name,'.mat'], 'imsegs');
    
    partitions = zeros(size(imsegs.segimage));
    nsp = imsegs.nseg;
    for sp=1:nsp
        partitions(imsegs.segimage == sp) = x(sp);
    end
    
    %% Show and Save Segmented Image
    
    % Show original image
    img_file = sprintf([datapath,'correlation-clustering/images/',instance_name,'.jpg']);
    im = imread(img_file);
    im_r = im(:,:,1);
    im_g = im(:,:,2);
    im_b = im(:,:,3);
    figure;
    imshow(im);
    
    % Show ground-truth segmentation
    
    length(unique(gt_seg));
    
    [cx,cy] = gradient(double(gt_seg));
    
    bdry_gt_seg = abs(cx) + abs(cy) > 0;
    
    mean_im_gt_seg_r = uint8(zeros(size(gt_seg)));
    mean_im_gt_seg_g = uint8(zeros(size(gt_seg)));
    mean_im_gt_seg_b = uint8(zeros(size(gt_seg)));
    
    
    for part=1:max(gt_seg(:))
        mean_im_gt_seg_r(gt_seg == part) = uint8(mean(im_r(gt_seg == part)));
        mean_im_gt_seg_g(gt_seg == part) = uint8(mean(im_g(gt_seg == part)));
        mean_im_gt_seg_b(gt_seg == part) = uint8(mean(im_b(gt_seg == part)));
    end
    
    mean_im_gt_seg_r(bdry_gt_seg) = 255;
    mean_im_gt_seg_g(bdry_gt_seg) = 255;
    mean_im_gt_seg_b(bdry_gt_seg) = 255;
    
    mean_im_gt_seg(:,:,1) = mean_im_gt_seg_r;
    mean_im_gt_seg(:,:,2) = mean_im_gt_seg_g;
    mean_im_gt_seg(:,:,3) = mean_im_gt_seg_b;
    
    figure;
    imshow(mean_im_gt_seg);
    
    % Show and save predictd segmentation
    
    length(unique(partitions));
    
    [cx,cy] = gradient(double(partitions));
    
    bdry_predicted = abs(cx) + abs(cy) > 0;
    
    mean_im_predicted_r = uint8(zeros(size(partitions)));
    mean_im_predicted_g = uint8(zeros(size(partitions)));
    mean_im_predicted_b = uint8(zeros(size(partitions)));
    
    
    for part=1:max(partitions(:))
        mean_im_predicted_r(partitions == part) = uint8(mean(im_r(partitions == part)));
        mean_im_predicted_g(partitions == part) = uint8(mean(im_g(partitions == part)));
        mean_im_predicted_b(partitions == part) = uint8(mean(im_b(partitions == part)));
    end
    
    mean_im_predicted_r(bdry_predicted) = 255;
    mean_im_predicted_g(bdry_predicted) = 255;
    mean_im_predicted_b(bdry_predicted) = 255;
    
    mean_im_predicted(:,:,1) = mean_im_predicted_r;
    mean_im_predicted(:,:,2) = mean_im_predicted_g;
    mean_im_predicted(:,:,3) = mean_im_predicted_b;
    
    figure;
    imshow(mean_im_predicted);
    
    if(save)
        mkdir(['../../result-images/correlation-clustering/',alg,'/']);
        imwrite(mean_im_predicted, ['../../result-images/correlation-clustering/',alg,'/',instance_name,'.png']);
    end

end