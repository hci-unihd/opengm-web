function plot_brain(alg,model,save)
    setup
    if(isnumeric(model))
        filepath  = ['../../results/brain2/',alg,'/'];
        files     = dir([filepath,'*.h5']);
        modelname = files(model).name;
        file      = [filepath,modelname];    
    else
        modelname = model;
        file      = ['../../results/brain2/',alg,'/',model,'.h5'];
    end
  
    
    x = h5read(file,'/states');
    zsize = numel(x)/(181*217);
    V = reshape(x,[181,217,zsize]);
    if(save)
        disp('Not implemented yet!')
    else
        figure; 
        title(modelname);
        subplot(1,4,1);
        imshow(double(V(:,:,round(zsize*1/5)))+1,[4;45;105;150;204]*ones(1,3)/255);
        subplot(1,4,2)
        imshow(double(V(:,:,round(zsize*2/5)))+1,[4;45;105;150;204]*ones(1,3)/255);
        subplot(1,4,3)
        imshow(double(V(:,:,round(zsize*3/5)))+1,[4;45;105;150;204]*ones(1,3)/255);
        subplot(1,4,4)
        imshow(double(V(:,:,round(zsize*4/5)))+1,[4;45;105;150;204]*ones(1,3)/255);
    end


end