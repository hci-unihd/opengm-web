function plot_dtf_chinesechar(alg,model,save)
%PLOT_DTF_CHINESECHAR -- Visualize result images.
%
% Author: Sebastian Nowozin <Sebastian.Nowozin@microsoft.com>
% Date: 30th October 2012

% Folder where you unzipped
% http://www.nowozin.net/sebastian/papers/DTF_CIP_instances.zip
% TODO: adjust this path
%dtf_path = '~/data/DTF_CIP_instances';

setup

if isnumeric(model)
	filepath = ['../../results/dtf-chinesechar/',alg,'/'];
	files = dir(sprintf('%s*.h5', filepath));
	modelname = files(model).name;
	file = [filepath,modelname];    
	modelname = strtok(modelname, '.');
else
	modelname = model;
	file = ['../../results/dtf-chinesechar',alg,'/',model,'.h5'];
end

x = h5read(file,'/states');
x = x + 1;
assert(min(x(:)) >= 1);
assert(max(x(:)) <= 2);

% Get resolution
[~,r]=strtok(modelname, '_');
[~,r]=strtok(r, '_');
[~,r]=strtok(r, '_');
[hstr,r]=strtok(r, '_');
[wstr,~]=strtok(r, '_');
height=sscanf(hstr,'%d');
width=sscanf(wstr,'%d');
x = reshape(x, [height, width])';

% Load ground truth
%K=load(sprintf('%s/cip_results_map.mat'));
%x_gt = K.sol{find_idx_by_modelname(K, modelname)}';

% Colormap

if save
	map=[0,0,0; 0,0,0; 1,1,1];
	mkdir(['../../result-images/dtf-chinesechar/',alg,'/']);
	imwrite(uint8(x), map, ['../../result-images/dtf-chinesechar/',alg, ...
		'/', modelname, '.png'], 'PNG', ...
		'Description', sprintf('MAP solution of algorithm %s on %s', alg, modelname));
else
	imagesc(x);
	axis image;
	colormap(gray);
	title(sprintf('Image "%s" MAP solution by algorithm "%s"', model, alg));
end


function idx=find_idx_by_modelname(K,modelname);
for idx=1:numel(K.instance_files)
	if strcmp(strtok(K.instance_files{idx},'.'), modelname)
		return;
	end
end
error(['Did not find model with name "', modelname, '".']);

