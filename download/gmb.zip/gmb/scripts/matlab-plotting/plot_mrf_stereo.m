function plot_mrf_stereo(alg,model,save)
    setup
    if(isnumeric(model))
        filepath  = ['../../results/mrf-stereo/',alg,'/'];
        files     = dir([filepath,'*.h5']);
        modelname = files(model).name;
        file      = [filepath,modelname];    
		modelname(end-2:end) = [];
    else
        modelname = model;
        file      = ['../../results/mrf-stereo/',alg,'/',model,'.h5'];
    end
    
    x = h5read(file,'/states');

	tmp = modelname; tmp(end-2:end) = []; 
	im = imread(['../../data/mrf-stereo/',tmp,'-gt.png']);

	if strcmp(modelname,'tsu-gm')
		numlabels = 16;
	elseif strcmp(modelname,'ted-gm')
		numlabels = 60;
	elseif strcmp(modelname,'ven-gm')
		numlabels = 20;
	else
		error( 'Unknown model' );
	end
    
    I = uint8(reshape(x,size(im,2), size(im,1)))';
    if(save)
    	mkdir(['../../result-images/mrf-stereo/',alg,'/']);
    	imwrite(I,([1;1;1]*[0:1/(numlabels-1):1])', ['../../result-images/mrf-stereo/',alg,'/',modelname,'.png']);
    else
    	imshow(I,([1;1;1]*[0:1/(numlabels-1):1])');
    end
end

