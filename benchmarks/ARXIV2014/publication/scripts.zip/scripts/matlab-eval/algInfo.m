function info = algInfo(alg)
    alg = strrep(alg,'_','-');

    
    G_IGNORE  = 0;
    G_LP  = 3;
    G_ILP = 4;
    G_MM  = 1;
    G_MP  = 2;
    G_SAM  = 5;
    G_UNKNOWN  = 6; 
    info = algInfoStructGen('-','-','-', G_UNKNOWN); 
   
    if(strcmp(alg(max(1,end-5):end), 'TABELS'))
       info = algInfoStructGen(alg,alg,alg, G_IGNORE); 
       return;
    end
    if(0==isempty(strfind(alg, 'CCFDB-R')))
       info = algInfoStructGen(alg,alg,alg, G_IGNORE); 
       return; 
    end
    
    
    switch alg
% Combinatorial Optimization
        case {'ogm-ilp','ilp'} 
            info = algInfoStructGen(alg,'ogm-ILP','ogm-ILP', G_ILP);    
        case 'ogm-ilp6' 
            info = algInfoStructGen(alg,'ogm-ILP (6h)','ogm-ILP (6h)', G_ILP);   
        case 'daoopt' 
            info = algInfoStructGen(alg,'daoopt','daoopt', G_IGNORE);  
        case 'daooptN' 
            info = algInfoStructGen(alg,'daooptN','daooptN', G_IGNORE);   
        case 'daoopt1' 
            info = algInfoStructGen(alg,'BRAOBB-1','BRAOBB-1', G_ILP);  
        case 'daoopt2' 
            info = algInfoStructGen(alg,'BRAOBB-2','BRAOBB-2', G_ILP); 
        case 'daoopt3' 
            info = algInfoStructGen(alg,'BRAOBB-3','BRAOBB-3', G_ILP);
        case 'ogm-astar' 
            info = algInfoStructGen(alg,'ogm-ATSAR','ogm-ASTAR', G_ILP);  
        case 'ms2' 
            info = algInfoStructGen(alg,'MCBC-pct','MCBC-pct', G_ILP); 
        case {'rilp','ilp-pct'} 
            info = algInfoStructGen(alg,'ogm-ILP-pct','ogm-ILP-pct', G_ILP);
        case 'iaddd' 
            info = algInfoStructGen(alg,'ADDD-BB','ADDD-BB', G_ILP); 
        case 'MC-CCI' 
            info = algInfoStructGen(alg,'MCI-CCI','MCI-CCI', G_ILP);
        case 'MC-CCIFD' 
            info = algInfoStructGen(alg,'MCI-CCIFD','MCI-CCIFD', G_ILP);
        case 'MC-CCFDB-CCIFD' 
            info = algInfoStructGen(alg,'MCI-CCFDB-CCIFD','MCI-CCFDB-CCIFD', G_ILP);
        case 'MC-TC-TCI' 
            info = algInfoStructGen(alg,'MCI-TC-TCI','MCI-TC-TCI', G_ILP);
        case 'MC-TC-MTC-TCI' 
            info = algInfoStructGen(alg,'MCI-TC-MTC-TCI','MCI-TC-MTC-TCI', G_ILP);
        case 'mca-pct' 
            info = algInfoStructGen(alg,'MCI-pct','MCI-pct', G_ILP);  
        case 'ogm-combilp'   
            info = algInfoStructGen(alg,'ogm-CombiLP','ogm-CombiLP',G_ILP);  
        case 'ogm-combilp-old'   
            info = algInfoStructGen(alg,'ogm-CombiLP-old','ogm-CombiLP-old',G_IGNORE);  
% Linear Programming            
        case 'ogm-lplp'      
            info = algInfoStructGen(alg,'ogm-LP-LP','ogm-LP-LP', G_LP);  
        case 'ogm-adsal'      
            info = algInfoStructGen(alg,'ogm-ADSAL','ogm-ADSAL', G_LP);  
        case {'ogm-ddh-bundle-a','ogm-dd-bundle-a','ogm-ddh-bundel-a','ogm-dd-bundel-a'}      
            info = algInfoStructGen(alg,'ogm-BUNDLE-A','ogm-BUNDLE-A', G_LP); 
        case {'ogm-ddha-bundle-a','ogm-dda-bundle-a','ogm-ddha-bundel-a','ogm-dda-bundel-a'}      
            info = algInfoStructGen(alg,'ogm-BUNDLE-A+','ogm-BUNDLE-A+', G_LP);  
        case {'ogm-ddhp-bundle-a','ogm-ddp-bundle-a','ogm-ddhp-bundel-a','ogm-ddp-bundel-a'}      
            info = algInfoStructGen(alg,'ogm-BUNDLE-A-','ogm-BUNDLE-A-', G_LP);   
        case {'ogm-ddh-bundle-h','ogm-dd-bundle-h','ogm-ddh-bundel-h','ogm-dd-bundel-h'}      
            info = algInfoStructGen(alg,'ogm-BUNDLE-H','ogm-BUNDLE-H', G_LP); 
        case {'ogm-ddh-sg','ogm-dd-sg'}      
            info = algInfoStructGen(alg,'ogm-SG-A','ogm-SG-A', G_LP); 
        case {'ogm-ddha-sg','ogm-dda-sg'}      
            info = algInfoStructGen(alg,'ogm-SG-A+','ogm-SG-A+', G_LP); 
        case {'ogm-ddhp-sg','ogm-ddp-sg'}      
            info = algInfoStructGen(alg,'ogm-SG-A-','ogm-SG-A-', G_LP); 
        case 'addd'   
            info = algInfoStructGen(alg,'ADDD','ADDD',G_LP); 
        case 'mplp'   
            info = algInfoStructGen(alg,'MPLP','MPLP',G_LP);
        case 'mplpc'   
            info = algInfoStructGen(alg,'MPLP-C','MPLP-C',G_LP); 
        case 'trws-pct'   
            info = algInfoStructGen(alg,'TRWS-pct','TRWS-pct',G_LP);
        case 'mcar-pct'   
            info = algInfoStructGen(alg,'MCR-pct','MCR-pct',G_LP);
        case 'lplp-pct'   
            info = algInfoStructGen(alg,'LPLP-pct','LPLP-pct',G_LP);             
        case 'trws-TL'   
            info = algInfoStructGen(alg,'TRWS-TL','TRWS-TL',G_LP); 
        case {'trws-TABLES','trws'}   
            info = algInfoStructGen(alg,'TRWS-TAB','TRWS-TAB',G_LP); 
        case {'mrf-trws-TL','mrf-trws-TL1','mrf-trws-TL2'}  
            info = algInfoStructGen(alg,'mrf-TRWS-TL','mrf-TRWS-TL',G_LP);     
        case 'mrf-trws-VIEW'   
            info = algInfoStructGen(alg,'mrf-TRWS-VIEW','mrf-TRWS-VIEW',G_LP);  
        case 'mrf-trws-TABLES'   
            info = algInfoStructGen(alg,'mrf-TRWS-TAB','mrf-TRWS-TAB',G_LP); 
        case 'qpbo'   
            info = algInfoStructGen(alg,'QPBO','QPBO',G_LP);   
        case 'MC-CC'   
            info = algInfoStructGen(alg,'MCR-CC','MCR-CC',G_LP);   
        case 'MC-CCFDB'   
            info = algInfoStructGen(alg,'MCR-CCFDB','MCR-CCFDB',G_LP);   
        case 'MC-CCFDB-OWC'   
            info = algInfoStructGen(alg,'MCR-CCFDB-OWC','MCR-CCFDB-OWC',G_LP);   
        case 'MC-TC-MTC'   
            info = algInfoStructGen(alg,'MCR-TC-MTC','MCR-TC-MTC',G_LP);                         
% Message Passing            
        case 'ogm-lbp'
            info = algInfoStructGen(alg,'ogm-LBP','ogm-LBP',G_MP); 
        case 'ogm-lbp05'
            info = algInfoStructGen(alg,'ogm-LBP-0.5','ogm-LBP-0.5',G_MP);
        case 'ogm-lbp09'
            info = algInfoStructGen(alg,'ogm-LBP-0.9','ogm-LBP-0.9',G_MP);
        case 'ogm-lbp095'
            info = algInfoStructGen(alg,'ogm-LBP-0.95','ogm-LBP-0.95',G_MP);        
        case 'ogm-trbp'
            info = algInfoStructGen(alg,'ogm-TRBP','ogm-TRBP',G_MP);  
        case 'ogm-trbp05'
            info = algInfoStructGen(alg,'ogm-TRBP-0.5','ogm-TRBP-0.5',G_MP); 
        case 'ogm-trbp08'
            info = algInfoStructGen(alg,'ogm-TRBP-0.8','ogm-TRBP-0.8',G_MP);
        case 'ogm-trbp095'
            info = algInfoStructGen(alg,'ogm-TRBP-0.95','ogm-TRBP-0.95',G_MP);
        case {'bps-TL','bps-TL1','bps-TL2'}
            info = algInfoStructGen(alg,'BPS-TL','BPS-TL',G_MP);  
        case {'bps-TABLES','bps'}
            info = algInfoStructGen(alg,'BPS-TAB','BPS-TAB',G_MP);          
        case {'mrf-bps-TL','mrf-bps-TL1','mrf-bps-TL2'}
            info = algInfoStructGen(alg,'mrf-BPS-TL','mrf-BPS-TL',G_MP);  
        case {'mrf-bp-TL','mrf-bp-TL1','mrf-bp-TL2'}
            info = algInfoStructGen(alg,'mrf-LBP-TL','mrf-LBP-TL',G_MP);   
        case 'mrf-bps-TABLES'
            info = algInfoStructGen(alg,'mrf-BPS-TAB','mrf-BPS-TAB',G_MP);  
        case 'mrf-bp-TABLES'
            info = algInfoStructGen(alg,'mrf-LBP-TAB','mrf-LBP-TAB',G_MP);            
%MOVE MAKING    
        case 'ogm-icm'
            info = algInfoStructGen(alg,'ogm-ICM','ogm-ICM',G_MM);  
        case 'ogm-lf1'
            info = algInfoStructGen(alg,'ogm-LF-1','ogm-LF-1',G_MM); 
        case 'ogm-lf2'
            info = algInfoStructGen(alg,'ogm-LF-2','ogm-LF-2',G_MM);
        case 'ogm-lf3'
            info = algInfoStructGen(alg,'ogm-LF-3','ogm-LF-3',G_MM); 
        case 'ogm-lf4'
            info = algInfoStructGen(alg,'ogm-LF-4','ogm-LF-4',G_MM);
        %    
        case {'ogm-trws-TL1-lf1','ogm-trws-TL2-lf1','ogm-trws-TL-lf1','ogm-trws-TABLES-lf1'}
            info = algInfoStructGen(alg,'ogm-TRWS-LF1','ogm-TRWS-LF1',G_MM);            
        case {'ogm-trws-TL1-lf2','ogm-trws-TL2-lf2','ogm-trws-TL-lf2','ogm-trws-TABLES-lf2'}
            info = algInfoStructGen(alg,'ogm-TRWS-LF2','ogm-TRWS-LF2',G_MM);
         %    
        case {'ogm-lbp-lf1'}
            info = algInfoStructGen(alg,'ogm-LBP-LF1','ogm-LBP-LF1',G_MM);            
        case {'ogm-lbp-lf2'}
            info = algInfoStructGen(alg,'ogm-LBP-LF2','ogm-LBP-LF2',G_MM);
        %      
        case 'ogm-fastpd-lf1'
            info = algInfoStructGen(alg,'ogm-FastPD-LF1','ogm-FastPD-LF1',G_MM);
        case 'ogm-fastpd-lf2'
            info = algInfoStructGen(alg,'ogm-FastPD-LF2','ogm-FastPD-LF2',G_MM);
        %
        case 'ogm-kl'
            info = algInfoStructGen(alg,'ogm-KL','ogm-KL',G_MM);  
        case 'afusion'
            info = algInfoStructGen(alg,'A-Fusion','$\\alpha$-Fusion',G_MM); 
        %
        case 'fastpd' 
            info = algInfoStructGen(alg,'FastPD','FastPD',G_MM); 
        case 'fastpd-pct' 
            info = algInfoStructGen(alg,'FastPD-pct','FastPD-pct',G_MM); 
        %
        case 'swap'
            info = algInfoStructGen(alg,'ab-Swap','$\\alpha\\beta$-Swap',G_MM); 
        case 'expansion'
            info = algInfoStructGen(alg,'a-Exp','$\\alpha$-Exp',G_MM);  
        case 'swap-view'
            info = algInfoStructGen(alg,'ab-Swap-VIEW','$\\alpha\\beta$-Swap-VIEW',G_MM); 
        case 'exp-view'
            info = algInfoStructGen(alg,'a-Exp-VIEW','$\\alpha$-Exp-VIEW',G_MM);
        %
        case {'mrf-swap-TL','mrf-ab-Swap-TL1','mrf-$\\alpha\\beta$-Swap-TL2'}
            info = algInfoStructGen(alg,'mrf-ab-Swap-TL','mrf-$\\alpha\\beta$-Swap-TL',G_MM); 
        case {'mrf-expansion-TL','mrf-a-Exp-TL1','mrf-$\\alpha$-Exp-TL2'}
            info = algInfoStructGen(alg,'mrf-a-Exp-TL','mrf-$\\alpha$-Exp-TL',G_MM); 
        case 'mrf-swap-TABLES'
            info = algInfoStructGen(alg,'mrf-ab-Swap-TAB','mrf-$\\alpha\\beta$-Swap-TAB',G_MM); 
        case 'mrf-expansion-TABLES'
            info = algInfoStructGen(alg,'mrf-a-Exp-TAB','mrf-$\\alpha$-Exp-TAB',G_MM);  
        case 'exp-pct'
            info = algInfoStructGen(alg,'a-Exp-pct','$\\alpha$-Exp-pct',G_MM);
%SAMPLING            
        case 'sa'
            info = algInfoStructGen(alg,'SA','SA',G_SAM);    
%IGNORE
        case {'xdaoopt','daooptsls'} 
            info = algInfoStructGen(alg,alg,alg, G_IGNORE);        
%UNKNOWN    
        otherwise
            info = algInfoStructGen(alg,[alg,'*'],[alg,'*'], G_IGNORE);
    end

end


function info = algInfoStructGen(tag,name,latex,group)
    info.tag   = tag;
    info.name  = name;
    info.latex = latex;
    info.group = group;
end
