function evaluate(dataset,varargin)
    generate_latextables  = 0; 
    generate_runtimeplots = 0;
    generate_htmltables   = 0; 
    generate_JSON         = 0; 
    evalGTflag            = 0;

    for k= 1 : size(varargin,2) 
        if(strcmp(varargin{k},'latextables'))
            generate_latextables = 1;  
        end
        if(strcmp(varargin{k},'htmltables'))
            generate_htmltables = 1;  
        end
        if(strcmp(varargin{k},'runtimeplots'))
            generate_runtimeplots = 1;  
        end
        if(strcmp(varargin{k},'json'))
            generate_JSON = 1;  
        end
        if(strcmp(varargin{k},'gteval'))
            evalGTflag=1;
        end  
        if(strcmp(varargin{k},'default'))
            generate_latextables  = 1; 
            generate_runtimeplots = 1; 
            evalGTflag            = 0;   
            break;
        end
    end

    set_gmb_paths;
    disp(' ');
    global benchmarktime; 
    global numTotalInstances;
    global numTotalExperiments;
  
    
    [res,names] = evaluation_load(dataset,evalGTflag);
    algsT        = fieldnames(res); 
    algs         = cell(0,1);
    for a=1:numel(algsT)
        info = algInfo(algsT{a});
        if(info.group <1 || info.group > 10)
            disp(['Skip ',info.name]);
        end
    end
    for g=1:10
        for a=1:numel(algsT)
            info = algInfo(algsT{a});
            if(info.group == g)
                algs{numel(algs)+1}=algsT{a};
            end
        end    
    end
    algs
    FN          = fieldnames(res.(algs{1}));  
    
    if(isempty(algs))
        disp('No methods found');
        return;
    else
        disp(['* -> Start processing ...']);
    end
    numberOfInstances = numel(res.(algs{1}).times);
    
    data.T  =       zeros(numel(algs),numberOfInstances);
    data.V  =  inf * ones(numel(algs),numberOfInstances);
    data.VE =  inf * ones(numel(algs),numberOfInstances);
    data.B  = -inf * ones(numel(algs),numberOfInstances);
    data.mesurenames = cell(0,1);
    
    if(numel(fieldnames(res.(algs{1})))>4)
        data.M = zeros(numel(algs),numberOfInstances,numel(FN)-4);
        for m=5:numel(FN)
            data.mesurenames{end+1} = FN{m};
        end
    end
    
    %% set up mask and fill data for algorithms/methods 
    % T  = runtime
    % V  = best objective value of a solution
    % VE = objective value of the final solution
    % B  = final lower bound on the objective
    mask  = zeros(1,numel(algs));
    for a=1:numel(algs)
       alg = algs{a};
       info = algInfo(alg);
       if(strcmp(info.name,'%')==0)
           mask(a)=1;
           disp(['*** Add : ',alg]);
       else
           disp(['*** Skip: ',alg]);
       end; 
       for i=1:numberOfInstances
            data.T(a,i)  = sum(res.(alg).times{i});
            data.V(a,i)  = min(res.(alg).values{i});
            data.VE(a,i) = res.(alg).values{i}(end);
            data.B(a,i)  = max(res.(alg).bounds{i});
            if(data.B(a,i)<-10^30), data.B(a,i)=-inf; end;
            for m=5:numel(FN)
                data.M(a,i,m-4)=res.(alg).(FN{m}){i};
            end
       end       
    end
  
    %% add time for this dataset to global benchmarktime
    tempTime = data.T(:);
    tempTime(isnan(data.T(:))) = 0;
    benchmarktime       = benchmarktime + sum(tempTime);
    numTotalInstances   = numTotalInstances + numberOfInstances; 
    numTotalExperiments = numTotalExperiments + numberOfInstances*sum(mask);
    
    %% calculate mean values, bounds, and times
    data.MT  = mean(data.T,2);
    data.MV  = mean(data.V,2);
    data.MVE = mean(data.VE,2);
    data.MB  = mean(data.B,2);
    
    %% calculate for each method how often the final value and bound was best among all methods
    % we define a value to be 'best' if it is less than 10^-8 far from the numerical best 
    if numel(algs)==1
        data.best = 1; 
        data.bestB = 1;
    else
        data.best   = mean( abs(data.V-ones(numel(algs),1)*min(data.V))<10^-5  | ...
                            abs(data.V-ones(numel(algs),1)*min(data.V))<10^-10 * (ones(numel(algs),1)*abs(min(data.V))+1) ...
                        ,2);
        data.bestVE = mean( abs(data.VE-ones(numel(algs),1)*min(data.VE))<10^-5 | ...
                            abs(data.VE-ones(numel(algs),1)*min(data.VE))<10^-10 * (ones(numel(algs),1)*abs(min(data.VE))+1) ...
                        ,2);
        data.bestB  = mean( abs(data.B-ones(numel(algs),1)*max(data.B))<10^-5 | ...
                            abs(data.B-ones(numel(algs),1)*max(data.B))<10^-10 * (ones(numel(algs),1)*abs(max(data.B))+1) ...
                        ,2);
    end
    data.opt = mean( (data.V-data.B) < 10^-5 | ...
                     (data.V-data.B) < 10^-10 * (abs(data.V)+10^-5) ...
                ,2);
    
    
    %% save latex tables
    if(generate_latextables)
        disp('* <- Generate LateX tables');
        global gmb_latextablepath;
        if(~exist(gmb_latextablepath))
           disp(['*!* Directory for LaTeX tables does not exists! Create ', gmb_latextablepath]);
           mkdir(gmb_latextablepath)
        end
        if(~exist([gmb_latextablepath,'/small']))
           disp(['*!* Directory for small LaTeX tables does not exists! Create ', gmb_latextablepath, '/small']);
           mkdir([gmb_latextablepath,'/small'])
        end
        if(~exist([gmb_latextablepath,'/small2']))
           disp(['*!* Directory for alternative small LaTeX tables does not exists! Create ', gmb_latextablepath, '/small2']);
           mkdir([gmb_latextablepath,'/small2'])
        end
        if(~exist([gmb_latextablepath,'/large']))
           disp(['*!* Directory for large LaTeX tables does not exists! Create ', gmb_latextablepath, '/large']);
           mkdir([gmb_latextablepath,'/large'])
        end
        
        saveShortTable(data, [gmb_latextablepath,'small/',dataset,'.tex'], algs, dataset,'scriptsize');
        saveShortTable(data, [gmb_latextablepath,'small2/',dataset,'.tex'], algs, dataset,'tiny');

        
        delete([gmb_latextablepath,'large/',dataset,'.tex']);
        delete([gmb_latextablepath,'large/',dataset,'-table1.tex']);
        delete([gmb_latextablepath,'large/',dataset,'-table2.tex']);
        if(sum(mask)<=8)
            saveLargeTable(data, [gmb_latextablepath,'large/',dataset,'.tex'], algs, dataset,names,mask);    
        else
            ind   = find(mask==1);
            mask1 = mask*0;
            mask2 = mask*0;
            mask1(ind(1:8))=1;
            mask2(ind(9:end))=1;

            saveLargeTable(data, [gmb_latextablepath,'large/',dataset,'-table1.tex'], algs, dataset,names,mask1);       
            saveLargeTable(data, [gmb_latextablepath,'large/',dataset,'-table2.tex'], algs, dataset,names,mask2);       
        end
    end
    
    %% save runtime plots
    if(generate_runtimeplots)  
        disp('* <- Generate LateX (tikz) runtime plots');   
        global gmb_plotpath; 
        if(~exist(gmb_plotpath))
           disp(['*!* Directory for LaTeX plots does not exists! Create ', gmb_plotpath]);
           mkdir(gmb_plotpath)
        end
        for i=1:min(numberOfInstances,1000)
            savePlot(res,algs, names,mask, dataset, gmb_plotpath,i)
        end
    end
    
    %% save HTML small tables
   if(generate_htmltables)
        disp('* <- Generate HTML tables');
        global gmb_htmltablepath;
        if(~exist(gmb_htmltablepath))
           disp(['*!* Directory for HTML tables does not exists! Create ', gmb_htmltablepath]);
           mkdir(gmb_htmltablepath);
        end
        if(~exist([gmb_htmltablepath,'/small']))
           disp(['*!* Directory for small HTML tables does not exists! Create ', gmb_htmltablepath, '/small']);
           mkdir([gmb_htmltablepath,'/small']);
        end
        if(~exist([gmb_htmltablepath,'/large']))
           disp(['*!* Directory for small HTML tables does not exists! Create ', gmb_htmltablepath, '/large']);
           mkdir([gmb_htmltablepath,'/large']);
        end
      
        saveShortHTMLTable(data, [gmb_htmltablepath,'small/',dataset,'.html'], algs);
        saveLargeHTMLTable(data, [gmb_htmltablepath,'large/',dataset,'.html'], algs,names,mask); 
   end
   if(generate_JSON) 
        global gmb_jsplotpath;  
        disp('* <- Generate JSON files for JavaScript web-plots'); 
        savePHPInstances([gmb_jsplotpath,'phpinstances/'],dataset,names,res,mask,algs); 
        for i=1:numberOfInstances
            saveJSON(res,algs, names,mask, dataset, [gmb_jsplotpath,'jsondata/'],i) ;  
        end
   end
end


%% RENAMING ALGORITHMS
% this function rename algorithms, this alows
% 1.) rename algorithms or replace with Latex-Macros
% 2.) rename equal algorithms with diffrent names, e.g. TRWS_TABLE and RWS_VIEW -> TRWS
% 3.) mask methods by an '%' such that they are not included in evaluation

% function alg = algName(algIn) 
%     algIn = strrep(algIn,'_','-');
%     alg = '%';
%     if(strcmp(algIn,'opengm-ilp')), alg='\\methodOPENGMILP'; end;
%     if(strcmp(algIn,'opengm-lplp')), alg='\\methodOPENGMLPLP'; end;
%     if(strcmp(algIn,'opengm-lbp')), alg='\\methodOPENGMLBP'; end;
%     if(strcmp(algIn,'opengm-trbp')), alg='\\methodOPENGMTRBP'; end;
%     if(strcmp(algIn,'opengm-ddbundle')), alg='\\methodOPENGMBUNDLEA'; end;
%     if(strcmp(algIn,'opengm-ddbundleA')), alg='\\methodOPENGMBUNDLEA'; end;
%     if(strcmp(algIn,'opengm-ddbundleH')), alg='\\methodOPENGMBUNDLEH'; end;
%     if(strcmp(algIn,'opengm-ddsubgrad')), alg='\\methodOPENGMSGA'; end;
%     if(strcmp(algIn,'opengm-ddhbundle')), alg='\\methodOPENGMBUNDLEA'; end;
%     if(strcmp(algIn,'opengm-ddhbundleA')), alg='\\methodOPENGMBUNDLEA'; end;
%     if(strcmp(algIn,'opengm-ddhbundleH')), alg='\\methodOPENGMBUNDLEH'; end;
%     if(strcmp(algIn,'opengm-ddhsubgrad')), alg='\\methodOPENGMSGA'; end;
%     if(strcmp(algIn,'opengm-astar')), alg='\\methodOPENGMASTAR'; end;
%     if(strcmp(algIn,'opengm-ilp6')), alg='\\methodOPENGMILP-6h'; end;
%     if(strcmp(algIn,'opengm-mc')), alg='\\methodMCA'; end;
%     if(strcmp(algIn,'opengm-mc6')), alg='\\methodMCA-6h'; end;
%     if(strcmp(algIn,'opengm-mc-fdo')), alg='\\methodMCA-fdo'; end;
%     if(strcmp(algIn,'opengm-afusion')), alg='\\methodAFUSION'; end;
%     if(strcmp(algIn,'opengm-icm')), alg='\\methodOPENGMICM'; end;
%     if(strcmp(algIn,'opengm-lf1')), alg='\\methodOPENGMLFICM'; end;
%    
%     if(strcmp(algIn,'KL')), alg='KL'; end;   
%     
%    if(strcmp(algIn,'MC-CC')), alg='MC-CC'; end;
%    if(strcmp(algIn,'MC-CCB')), alg='MC-CCB'; end;
%    if(strcmp(algIn,'MC-CCFD')), alg='MC-CCFD'; end;
%    if(strcmp(algIn,'MC-CCFDB')), alg='MC-CCFDB'; end;
%    %
%    if(strcmp(algIn,'MC-CC-OWC')), alg='MC-CC-OWC'; end;
%    if(strcmp(algIn,'MC-CCB-OWC')), alg='MC-CCB-OWC'; end;
%    if(strcmp(algIn,'MC-CCFD-OWC')), alg='MC-CCFD-OWC'; end;
%    if(strcmp(algIn,'MC-CCFDB-OWC')), alg='MC-CCFDB-OWC'; end;
%    %
%    if(strcmp(algIn,'MC-CC-CCI')), alg='MC-CC-CCI'; end;
%    if(strcmp(algIn,'MC-CCFDB-CCIFD')), alg='MC-CCFDB-CCIFD'; end;
%    if(strcmp(algIn,'MC-CCI')), alg='MC-CCI'; end;
%    if(strcmp(algIn,'MC-CCIFD')), alg='MC-CCIFD'; end;
%    if(strcmp(algIn,'MC-ICCFDB')), alg='MC-ICCFDB'; end;
%    if(strcmp(algIn,'MC-ICC')), alg='MC-ICC'; end;
%    if(strcmp(algIn,'MC-TC-MTC')), alg='MC-T-MT'; end;
%     
%     
% %MRF-Bench Sovers
%  
%     if(strcmp(algIn,'mrf-expansion-TL')), alg='\\methodMRFEXPTL'; end;
%     if(strcmp(algIn,'mrf-swap-TL')),      alg='\\methodMRFSWAPTL'; end;
%     if(strcmp(algIn,'mrf-trws-TL')),      alg='\\methodMRFTRWSTL'; end;
%     if(strcmp(algIn,'mrf-lbp-TL')),       alg='\\methodMRFLBPTL'; end;
%     if(strcmp(algIn,'mrf-bp-TL')),        alg='\\methodMRFLBPTL'; end;
%     if(strcmp(algIn,'mrf-bps-TL')),       alg='\\methodMRFBPSTL'; end;
% 
%     if(strcmp(algIn,'mrf-expansion-TL1')), alg='\\methodMRFEXPTL'; end;
%     if(strcmp(algIn,'mrf-swap-TL1')),      alg='\\methodMRFSWAPTL'; end;
%     if(strcmp(algIn,'mrf-trws-TL1')),      alg='\\methodMRFTRWSTL'; end;
%     if(strcmp(algIn,'mrf-lbp-TL1')),       alg='\\methodMRFLBPTL'; end;
%     if(strcmp(algIn,'mrf-bp-TL1')),        alg='\\methodMRFLBPTL'; end;
%     if(strcmp(algIn,'mrf-bps-TL1')),       alg='\\methodMRFBPSTL'; end;
% 
%     if(strcmp(algIn,'mrf-expansion-TL2')), alg='\\methodMRFEXPTL'; end;
%     if(strcmp(algIn,'mrf-swap-TL2')),      alg='\\methodMRFSWAPTL'; end;
%     if(strcmp(algIn,'mrf-trws-TL2')),      alg='\\methodMRFTRWSTL'; end;
%     if(strcmp(algIn,'mrf-lbp-TL2')),       alg='\\methodMRFLBPTL'; end;
%     if(strcmp(algIn,'mrf-bp-TL2')),        alg='\\methodMRFLBPTL'; end;
%     if(strcmp(algIn,'mrf-bps-TL2')),       alg='\\methodMRFBPSTL'; end;
% 
%     if(strcmp(algIn,'mrf-expansion-TABLES')), alg='\\methodMRFEXPTABLES'; end;
%     if(strcmp(algIn,'mrf-swap-TABLES')),      alg='\\methodMRFSWAPTABLES'; end;
%     if(strcmp(algIn,'mrf-trws-TABLES')),      alg='\\methodMRFTRWSTABLES'; end;
%     if(strcmp(algIn,'mrf-lbp-TABLES')),       alg='\\methodMRFLBPTABLES'; end;
%     if(strcmp(algIn,'mrf-bp-TABLES')),        alg='\\methodMRFLBPTABLES'; end;
%     if(strcmp(algIn,'mrf-bps-TABLES')),       alg='\\methodMRFBPSTABLES'; end;
% 
% 
%     if(strcmp(algIn,'mrf-expansion-VIEW')), alg='\\methodMRFEXPVIEW'; end;
%     if(strcmp(algIn,'mrf-swap-VIEW')),      alg='\\methodMRFSWAPVIEW'; end;
%     if(strcmp(algIn,'mrf-trws-VIEW')),      alg='\\methodMRFTRWSVIEW'; end;
%     if(strcmp(algIn,'mrf-lbp-VIEW')),       alg='\\methodMRFLBPVIEW'; end;
%     if(strcmp(algIn,'mrf-bp-VIEW')),        alg='\\methodMRFLBPVIEW'; end;
%     if(strcmp(algIn,'mrf-bps-VIEW')),       alg='\\methodMRFBPSVIEW'; end;
%    
%     if(strcmp(algIn,'trws')),      alg='\\methodTRWS'; end;
%     if(strcmp(algIn,'bps')),       alg='\\methodBPS'; end;
%     if(strcmp(algIn,'expansion')), alg='\\methodEXP'; end;
%     if(strcmp(algIn,'swap')),      alg='\\methodSWAP'; end;
%    
%     if(strcmp(algIn,'trws-TL')),      alg='\\methodTRWSTL'; end;
%     if(strcmp(algIn,'bps-TL')),       alg='\\methodBPSTL'; end;
%     if(strcmp(algIn,'expansion-TL')), alg='\\methodEXPTL'; end;
%     if(strcmp(algIn,'swap-TL')),      alg='\\methodSWAPTL'; end;
%      
%     if(strcmp(algIn,'trws-TL1')),      alg='\\methodTRWSTL'; end;
%     if(strcmp(algIn,'bps-TL1')),       alg='\\methodBPSTL'; end;
%     if(strcmp(algIn,'expansion-TL1')), alg='\\methodEXPTL'; end;
%     if(strcmp(algIn,'swap-TL1')),      alg='\\methodSWAPTL'; end;
%     
%     if(strcmp(algIn,'trws-TL2')),      alg='\\methodTRWSTL'; end;
%     if(strcmp(algIn,'bps-TL2')),       alg='\\methodBPSTL'; end;
%     if(strcmp(algIn,'expansion-TL2')), alg='\\methodEXPTL'; end;
%     if(strcmp(algIn,'swap-TL2')),      alg='\\methodSWAPTL'; end;
%     
%     if(strcmp(algIn,'trws-TABLES')),      alg='\\methodTRWSTABLES'; end;
%     if(strcmp(algIn,'bps-TABLES')),       alg='\\methodBPSTABLES'; end;
%     if(strcmp(algIn,'expansion-TABLES')), alg='\\methodEXPTABLES'; end;
%     if(strcmp(algIn,'swap-TABLES')),      alg='\\methodSWAPTABLES'; end;    
%     
%     if(strcmp(algIn,'trws-VIEW')),      alg='\\methodTRWSVIEW'; end;
%     if(strcmp(algIn,'bps-VIEW')),       alg='\\methodBPSVIEW'; end;
%     if(strcmp(algIn,'expansion-view')), alg='\\methodEXPVIEW'; end;
%     if(strcmp(algIn,'swap-view')),      alg='\\methodSWAPVIEW'; end;    
%     
%     if(strcmp(algIn,'mc-relaxed')), alg='\\methodMCR'; end;
%     if(strcmp(algIn,'FastPD')), alg='\\methodFASTPD'; end;
%     if(strcmp(algIn,'daoopt')),  alg='\\methodOtten'; end;
%     if(strcmp(algIn,'daooptN')), alg='\\methodOtten*'; end;
%     if(strcmp(algIn,'daoopt-p')),  alg='\\methodOtten-p'; end;
%     if(strcmp(algIn,'daooptN-p')),  alg='\\methodOtten*-p'; end;
%     if(strcmp(algIn,'opengm-multicut')), alg='\\methodMCA'; end;
%     if(strcmp(algIn,'mc')), alg='\\methodMCA'; end;
%     if(strcmp(algIn,'mcr')), alg='\\methodMCR'; end;
%     if(strcmp(algIn,'ms2')), alg='\\methodMAXCUT'; end;
%     if(strcmp(algIn,'qpbo')), alg='\\methodQPBO'; end;
%     if(strcmp(algIn,'sa')), alg='\\methodSA'; end;
%     if(strcmp(algIn,'fastpd-pct')), alg='\\methodFASTPD-pct'; end;
%     if(strcmp(algIn,'trws-pct')),  alg='\\methodTRWS-pct'; end;
%     if(strcmp(algIn,'exp-pct')),  alg='\\methodEXP-pct'; end;
%     if(strcmp(algIn,'fastpd-p')), alg='\\methodFASTPD-p'; end;
%     if(strcmp(algIn,'trws-p')), alg='\\methodTRWS-p'; end;
%     if(strcmp(algIn,'exp-p')),  alg='\\methodEXP-p'; end; 
%     if(strcmp(algIn,'fastpd-pct')), alg='\\methodFASTPD-pct'; end;
%     if(strcmp(algIn,'trws-pct')), alg='\\methodTRWS-pct'; end;
%     if(strcmp(algIn,'exp-pct')),  alg='\\methodEXP-pct'; end; 
%     
%     if(strcmp(algIn,'rmc')), alg='RMC'; end;
%     if(strcmp(algIn,'rmc-pc')), alg='RMC-pc'; end;
%     if(strcmp(algIn,'rmcr-pct')), alg='RMCR-pct'; end;
%     if(strcmp(algIn,'rlp-pct')),  alg='RLP-pct'; end; 
%     if(strcmp(algIn,'rilp')),  alg='RILP'; end;
% %LF
%     if(strcmp(algIn,'lbp-lf2')) alg='\\methodLBPLF'; end;
%     if(strcmp(algIn,'fastpd-lf2')) alg='\\methodFASTPDLF'; end;
%     if(strcmp(algIn,'mrf-bp-TL')) alg='\\methodMRFLBPLF'; end;
%     if(strcmp(algIn,'trws-TL-lf2')) alg='\\methodTRWSLF'; end;
%     if(strcmp(algIn,'trws-TABLES-lf2')) alg='\\methodTRWSLF'; end;
%     if(strcmp(algIn,'trws-lf2')) alg='\\methodTRWSLF'; end;
%     
%     if(strcmp(algIn,'trws-L8')) alg='TRWS-L8'; end;
%     if(strcmp(algIn,'trws-L4')) alg='TRWS-L4'; end;
%     if(strcmp(algIn,'trws5000-L4')) alg='TRWS5000-L4'; end;
%     if(strcmp(algIn,'opengm-lf2-L8')) alg='LF2-L8'; end;
%     if(strcmp(algIn,'opengm-lf2-L4')) alg='LF2-L4'; end;
%     if(strcmp(algIn,'opengm-lf3-L4')) alg='LF3-L4'; end;
%     if(strcmp(algIn,'opengm-lf4-L4')) alg='LF4-L4'; end;
%     
% end


%% Write short latex table to file

function saveShortTable(data, file, algs, dataset, textsize)
    if(~isempty(file))
        fid = fopen(file, 'w'); 
        fprintf(fid,['\\begin{table}[H]\n']);
        fprintf(fid,['\\',textsize,'\n\\centering\n']);
        %fprintf(fid,['\\centering\n']);
        fprintf(fid,['\\caption{',dataset,' (',num2str(size(data.T,2)),' instances)}\n']);
        fprintf(fid,['\\label{tab:smalltable-',dataset,'}\n']);
        fprintf(fid,['\\begin{tabular}{lrrrrr']);
        for i=1:numel(data.mesurenames)
          fprintf(fid,'r');   
        end
        fprintf(fid,['}\n\\toprule\n']);
    end;
    text = [ sprintf('%20s','algorithm'),' & ',...
             sprintf('%15s','runtime'),'       & ',...
             sprintf('%15s','value'),' & ',...
             sprintf('%15s','bound'),' & ',...
             sprintf('%10s','best'),' & ',...
             sprintf('%10s','ver. opt'), '   ']; 
    for i=1:numel(data.mesurenames)
        text =[text,' & ', sprintf('%15s',data.mesurenames{i}),' '];
    end
    if(~isempty(file)),     
        fprintf(fid,[text,'\\\\ \\midrule \n']);
    else
        disp(text);
    end
    MedianT  = median(data.T,2);
    for a =1:numel(algs)    
        info = algInfo(algs{a});
        algName = info.latex;
        if(max(abs(data.MVE))<10)
            form ='% 10.4f';
        else
            form ='% 10.2f';
        end
        if(~isempty(file)),
            if(a>1)
                info0 = algInfo(algs{a-1});
                if(info0.group ~= info.group)
                    fprintf(fid,'\\cmidrule{1-1} \n');   
                end
            end
        end
        if(size(data.T,2)<1000)
           N = size(data.T,2);
           if(isinf(data.MB(a)))
               boundtext = sprintf('%14s','-\\infty');    
           else
               boundtext = sprintf('%13s',num2str(data.MB(a),form));              
           end
           text = [ sprintf('%20s',algName),' & ',...
                     '$',sprintf('%13s',num2str(data.MT(a),'% 10.2f')),'$ sec & ', ...
                     '$',sprintf('%13s',num2str(data.MVE(a),form)),'$ & ', ...
                     '$',boundtext,'$ & ', ... 
                     '$',sprintf('%8s',num2str(floor(data.best(a)*N+0.01))),'$ & ', ...
                     '$',sprintf('%8s',num2str(floor(data.opt(a)*N+0.01))),'$ ']; 
                    % '$',sprintf('%13s',num2str(data.MT(a),'% 10.2f')),'$ $(',num2str(MedianT(a),'% 10.2f'),')$ sec & ', ...                    
                     %'$',sprintf('%8s',num2str(floor(data.best(a)*N+0.01))),'/',num2str(N),'$ & ', ...
                     %'$',sprintf('%8s',num2str(floor(data.opt(a)*N+0.01))),'/',num2str(N),'$ ']; 
                    
        else
            if(isinf(data.MB(a)))
               boundtext = sprintf('%14s','-\\infty');    
            else
               boundtext = sprintf('%13s',num2str(data.MB(a),form));              
            end
            text = [ sprintf('%20s',algName),' & ',...
                     '$',sprintf('%13s',num2str(data.MT(a),'% 10.2f')),'$ sec & ', ...
                     '$',sprintf('%13s',num2str(data.MVE(a),form)),'$ & ', ...
                     '$',boundtext,'$ & ', ...
                     '$',sprintf('%7s',num2str(data.best(a)*100,'% 3.2f')),'$ \\%% & ', ...
                     '$',sprintf('%7s',num2str(data.opt(a)*100,'% 3.2f')),'$ \\%% '];  % '$',sprintf('%13s',num2str(data.MT(a),'% 10.2f')),'$ $(',num2str(MedianT(a),'% 10.2f'),')$ sec & ', ...
                   
        end 
        for i=1:numel(data.mesurenames)
            text =[text,' & $',sprintf('%13s',num2str(mean(data.M(a,:,i)),'% 8.4f')),'$ '];
        end
        if(~isempty(file)), 
            fprintf(fid,[text,'\\\\ \n']);
        else
            disp(text);
        end    
    end
    if(~isempty(file))
        fprintf(fid,['\\bottomrule\n\\end{tabular}\n\\end{table}']);
        fclose(fid);
    end;
end



function saveLargeTable(data, file, algs, dataset,names,mask) 
    fid = fopen(file, 'w'); 
    table = '{\\scriptsize\\begin{longtable}{|l|l|'; 
    for i=1:numel(algs)
        if(mask(i))
            table=[table,'r|'];
        end;
    end
    table = [table,'}']; 
    fprintf(fid,[table,' \n']); 
    fprintf(fid,['\\caption[]{',dataset,'}\n\\\\\\hline\n']);
  
    
    table=['\\textbf{',dataset,'}& '];
    for i=1:numel(algs)
        if(mask(i))
            info = algInfo(algs{i});
            table=[table,'& ',info.latex];
        end;
    end
   
    fprintf(fid,[table,'\\\\\\hline\n']);
    fprintf(fid,'\\endfirsthead\n'); 
    fprintf(fid,['\\hline\n',table,'\\\\\\hline\n']); 
    fprintf(fid,'\\endhead\n');
    
    table=''; 
    BV = (data.VE-ones(size(data.VE,1),1)*min(data.VE))<10^-5;
    BB = (ones(size(data.B,1),1)*max(data.B)-data.B)<10^-5;   
     
   
    for m=1:size(data.V,2) 
        if(max(abs(data.V(:,m)))<10)
            form ='% 10.4f';
        else
            form ='% 10.2f';
        end
  
        table = [table,strrep(names{m},'_','\\_')];
        table = [table,'& value'];
        for a=1:numel(algs)
            if(mask(a))
                if(BV(a,m)) 
                    table=[table,'& \\bf ',num2str(data.VE(a,m),form)];
                else
                    table=[table,'& ',num2str(data.VE(a,m),form)];
                end
            end
        end
        table = [table,'\\\\\\nopagebreak\n'];
        fprintf(fid,table); table='';
        table = [table,'& bound'];
        for a=1:numel(algs) 
            if(mask(a))
                if(BB(a,m))
                    table=[table,'& \\bf ',num2str(data.B(a,m),form)];
                else
                    table=[table,'& ',num2str(data.B(a,m),form)];
                end
            end
        end
        table = [table,'\\\\\\nopagebreak\n']; 
        fprintf(fid,table); table=''; 
        table = [table,'& runtime'];
        for a=1:numel(algs)
            if(mask(a))
            table=[table,'& ',num2str(data.T(a,m),'%4.2f')]; 
            end
        end
        table = [table,'\\\\\\hline\n'];
        fprintf(fid,table); table='';
    end
    
    if(max(abs(data.MV))<10)
        form ='% 10.4f';
    else
        form ='% 10.2f';
    end
  
     %Mean Energy
    fprintf(fid,'\\hline\n');
    fprintf(fid,table); table=['\\textbf{mean energy} & '];
    for a=1:numel(algs) 
        if(mask(a))
            table=[table,'& ',num2str(data.MV(a),form)];
        end;
    end
    table = [table,'\\\\\\hline\n'];
    fprintf(fid,table); table='';   
    %Mean Bound 
    fprintf(fid,table); table=['\\textbf{mean bound} & '];
    for a=1:numel(algs)
        if(mask(a))
            table=[table,'& ',num2str(data.MB(a),form)];
        end;
    end
    table = [table,'\\\\\\hline\n'];
    fprintf(fid,table); table=''; 
    %Mean Runtime 
    fprintf(fid,table); table=['\\textbf{mean runtime} & '];
    for a=1:numel(algs)
        if(mask(a))
            table=[table,'& ',num2str(data.MT(a),'%4.2f')];
        end;
    end
    table = [table,'\\\\\\hline\n'];
    fprintf(fid,table); table='';  
    %Precentage best value 
    table=['\\textbf{best value} & '];
    for a=1:numel(algs)
        if(mask(a))
            table=[table,'& ',num2str(data.best(a)*100,'%4.2f'),''];
        end;
    end
    table = [table,'\\\\\\hline\n'];
    fprintf(fid,table); table=''; 
     %Precentage best bound 
    table=['\\textbf{best bound} & '];
    for a=1:numel(algs)
        if(mask(a))
            table=[table,'& ',num2str(data.bestB(a)*100,'%4.2f'),''];
        end;
    end
    table = [table,'\\\\\\hline\n'];
    fprintf(fid,table); table=''; 
    %Precentage guranteed optimum 
    table=['\\textbf{verified opt} & '];
    for a=1:numel(algs)
        if(mask(a))
            table=[table,'& ',num2str(data.opt(a)*100,'%4.2f'),''];
        end
    end
    table = [table,'\\\\\\hline\n'];
    fprintf(fid,table); table='';
    

    fprintf(fid,'\\end{longtable}}');
    fclose(fid);
      
end


%% save tikz-latex-runtime-plots
function savePlot(res,algs, names,mask, dataset, plotpath, in)
    %disp('Prepare LaTeX-Plots');
    %disp(plotpath);
    maxEl  = 0;
    maxT   = 0;
    minE   = inf;
    maxB   = -inf;
  
    for a=1:numel(mask)
        if(mask(a)==0), continue; end;
        maxEl = max(maxEl,numel(res.(algs{a}).times{in}));    
    end
 
    delta = 0.005;
    c = 0;
    LE = [];
    for a=1:numel(mask)
            if(mask(a)==0), continue; end;
            N = numel(res.(algs{a}).times{in});
            maxT = max(maxT, sum(res.(algs{a}).times{in}));
            maxB = max(maxB, max(res.(algs{a}).bounds{in}));
            minE = min(minE, min(res.(algs{a}).values{in}));
            LE = [LE ,min(res.(algs{a}).values{in}) ];
            c = c+1;    
    end
    
    upperE = min(max(LE),minE+abs(minE));
    if(maxB==-inf)
        maxB = minE-delta*abs(minE);
    end
    
    if(exist(plotpath,'dir')==0),                                       
        mkdir(plotpath); 
    end;  
    if(exist([plotpath,'tikz-latex-runtimeplots/'],'dir')==0),          
        mkdir([plotpath,'tikz-latex-runtimeplots/']); 
    end;  
    if(exist([plotpath,'tikz-latex-runtimeplots/',dataset],'dir')==0),  
        mkdir([plotpath,'tikz-latex-runtimeplots/',dataset]); 
    end;
    %disp([plotpath, dataset,'/',names{in},'.tex']);
    texfid = fopen([plotpath, 'tikz-latex-runtimeplots/',dataset,'/',names{in},'.tex'], 'w'); 
    
    fprintf(texfid,'\\documentclass{article}\n');
    fprintf(texfid,'\\usepackage{tikz} \n');
    fprintf(texfid,'\\usepackage{graphicx}             % include images\n');
    fprintf(texfid,'\\usepackage{amsmath}              % math environments\n');
    fprintf(texfid,'\\usepackage{amssymb}              % math symbols\n');
    fprintf(texfid,'\\usepackage{pgfplots}             % draw plots in tikz style\n');
    fprintf(texfid,'\\usepackage{xspace}\n');
    fprintf(texfid,'\\usepackage{pgfplotstable}\n');
    fprintf(texfid,'\\usepackage{filecontents}\n');
    fprintf(texfid,'\n');
    fprintf(texfid,'\\usepackage[active,pdftex,tightpage]{preview}\n');
    fprintf(texfid,'\\PreviewEnvironment[{[]}]{tikzpicture}\n');
    fprintf(texfid,'\n');
    fprintf(texfid,'\\input{../methodnames.tex}\n');
    fprintf(texfid,'\\input{../plottingparameters.tex}\n');
    fprintf(texfid,'\\begin{document}\n');
    fprintf(texfid,['\\begin{figure}[H]\n']);
    fprintf(texfid,['\\centering\n']);
    fprintf(texfid,['\\begin{tikzpicture}\n']);    
    fprintf(texfid,['\\begin{semilogxaxis}[\n']);
    fprintf(texfid,['restrict y to domain=',num2str(maxB-delta*abs(maxB)),':',num2str(upperE+delta*abs(upperE)),',\n']);
    fprintf(texfid,['xlabel = {runtime},\n']);
   % fprintf(texfid,['ylabel = {energy},\n']);
    fprintf(texfid,['xmin = 0,\n']);
    fprintf(texfid,['xmax = ',num2str(10^(ceil(log(maxT)+1))),',\n']);
    fprintf(texfid,['ymin =  ',num2str(maxB-delta*abs(maxB)),',\n']);
    fprintf(texfid,['ymax =  ',num2str(upperE+delta*abs(upperE)),',\n']);   
    fprintf(texfid,['xtick       = {']);
    if(maxT>1),     fprintf(texfid,' 1 '); end
    if(maxT>60),    fprintf(texfid,', 60 '); end
    if(maxT>3600),  fprintf(texfid,', 3600 '); end
    fprintf(texfid,'},\n');
   
    fprintf(texfid,'xticklabels = {');
    if(maxT>1),     fprintf(texfid,' 1 sec.'); end
    if(maxT>60),    fprintf(texfid,' , 1 min. '); end
    if(maxT>3600),  fprintf(texfid,' , 1 hour '); end
    fprintf(texfid,'},\n');
    
    ymax = upperE+delta*abs(upperE);
    %fprintf(texfid,['ytick       = {',num2str(floor(maxB-delta/2*abs(maxB))),', ',num2str(minE),', ',num2str(ceil(upperE+delta/2*abs(upperE))),' },\n']);
    %fprintf(texfid,['yticklabels = {$',num2str(floor(maxB-delta/2*abs(maxB))),'$, $',num2str(minE),'$, $',num2str(ceil(upperE+delta/2*abs(upperE))),'$ },\n']);
    fprintf(texfid,['ytick       = {',num2str(minE),', ',num2str(ceil((minE+ymax)/2)),', ',num2str(ceil(ymax)),' },\n']);
    fprintf(texfid,['yticklabels = {$',num2str(minE),'$, $',num2str(ceil((minE+ymax)/2)),'$, $',num2str(ceil(ymax)),'$ },\n']);
   
    fprintf(texfid,['width = 0.9\\textwidth,\n']);
    fprintf(texfid,['scaled ticks = false\n]\n']);
      
    for a=1:numel(mask)
        if(mask(a)==0), continue; end; 
        if(exist([plotpath,dataset,'/',names{in}],'dir')==0), mkdir([plotpath,dataset,'/',names{in}]); end;
        V = res.(algs{a}).values{in};
        for i=2:numel(V), V(i) = min(V(i-1:i)); end;
        datafile = [plotpath, dataset,'/',names{in},'/',algs{a},'.data'];
        datafid = fopen(datafile, 'w');
        fprintf(datafid,['T  V  B   \n']);
        if numel(res.(algs{a}).times{in})<200
            for i=1:numel(res.(algs{a}).times{in});
                fprintf(datafid,[num2str(res.(algs{a}).times{in}(i),'%10.2f'),' ',num2str(V(i),'%10.2f'),' ',num2str(res.(algs{a}).bounds{in}(i),'%10.2f'),' \n']);        
            end
        else
            for i=1:floor(numel(res.(algs{a}).times{in})/1000):numel(res.(algs{a}).times{in});
                fprintf(datafid,[num2str(res.(algs{a}).times{in}(i),'%10.2f'),' ',num2str(V(i),'%10.2f'),' ',num2str(res.(algs{a}).bounds{in}(i),'%10.2f'),' \n']);        
            end
            fprintf(datafid,[num2str(res.(algs{a}).times{in}(end),'%10.2f'),' ',num2str(V(end),'%10.2f'),' ',num2str(res.(algs{a}).bounds{in}(end),'%10.2f'),' \n']);
        end
        fclose(datafid);
        
        if(min(res.(algs{a}).values{in})>upperE+delta*abs(upperE) || sum(isnan(res.(algs{a}).values{in}))>0 || sum(isnan(res.(algs{a}).times{in})>0) || sum(isnan(res.(algs{a}).bounds{in}))>0 ), continue; end;
        datafile = [names{in},'/',algs{a},'.data'];
        fprintf(texfid,['\\addplot[',algs{a},']\n']);
        fprintf(texfid,['table[x=T, y=V ]\n']);
        fprintf(texfid,['{',datafile,'};\n']);
        info = algInfo(algs{a});
        fprintf(texfid,['\\addlegendentry{',info.latex,'} \n\n']); 
    end    
    for a=1:numel(mask)
        if(mask(a)==0), continue; end;
        datafile = [names{in},'/',algs{a},'.data'];
        if(max(res.(algs{a}).bounds{in})<maxB-delta*abs(maxB) || sum(isnan(res.(algs{a}).values{in}))>0 || sum(isnan(res.(algs{a}).times{in})>0)|| sum(isnan(res.(algs{a}).bounds{in}))>0 ), continue; end;
        fprintf(texfid,['\\addplot[',algs{a},']\n']);
        fprintf(texfid,['table[x=T, y=B ]\n']);
        fprintf(texfid,['{',datafile,'};\n\n']);        
    end
   
 
    fprintf(texfid,'\\end{semilogxaxis}\n');    
    fprintf(texfid,'\\end{tikzpicture}\n');   
    fprintf(texfid,'\\end{figure}\n');  
    fprintf(texfid,'\\end{document}\n');
    fclose(texfid);
end

% function html = name2HTML(name)
%     html=['x',name];
%     
%     if(strcmp(name,'\\methodOPENGMILP')), html='ogm-ILP'; end; 
%     if(strcmp(name,'\\methodOPENGMILP-6h')), html='ogm-ILP (6h)'; end;
%     if(strcmp(name,'\\methodOPENGMLPLP')), html='ogm-LP-LP'; end;
%     if(strcmp(name,'\\methodOPENGMLBP')), html='ogm-LBP'; end;
%     if(strcmp(name,'\\methodOPENGMTRBP')), html='ogm-TRBP'; end;
%     if(strcmp(name,'\\methodOPENGMBUNDLEA')), html='ogm-BUNDLE-A'; end;
%     if(strcmp(name,'\\methodOPENGMBUNDLEH')), html='ogm-BUNDLE-H'; end;
%     if(strcmp(name,'\\methodOPENGMSGA')), html='ogm-SUBGRAD-A'; end;
%     if(strcmp(name,'\\methodOPENGMASTAR')), html='ogm-ASTAR'; end;
% 
%     if(strcmp(name,'\\methodLBPLF')), html='ogm-LBP-LF2'; end;
%     if(strcmp(name,'\\methodFASTPDLF')), html='FastPD-LF2'; end;
%     if(strcmp(name,'\\methodMRFLBPLF')), html='mrf-LBP-LF2'; end;
% 
%     %MRF-Bench Sovers
%     if(strcmp(name,'\\methodMRFTRWS')), html='mrf-TRWS'; end;
%     if(strcmp(name,'\\methodMRFBPS')), html='mrf-BPS'; end;
%     if(strcmp(name,'\\methodMRFBP')), html='mrf-LBP'; end;
%     if(strcmp(name,'\\methodMRFLBP')), html='mrf-LBP'; end;
%     if(strcmp(name,'\\methodMRFEXP')), html='mrf-EXPANSION'; end;
%     if(strcmp(name,'\\methodMRFSWAP')), html='mrf-SWAP'; end;
% 
%     if(strcmp(name,'\\methodMRFTRWSTL')), html='mrf-TRWS'; end;
%     if(strcmp(name,'\\methodMRFBPSTL')), html='mrf-BPS'; end;
%     if(strcmp(name,'\\methodMRFBPTL')), html='mrf-LBP'; end;
%     if(strcmp(name,'\\methodMRFLBPTL')), html='mrf-LBP'; end;
%     if(strcmp(name,'\\methodMRFEXPTL')), html='mrf-EXPANSION'; end;
%     if(strcmp(name,'\\methodMRFSWAPTL')), html='mrf-SWAP'; end;
% 
%     if(strcmp(name,'\\methodMRFTRWSTABLES')), html='mrf-TRWS'; end;
%     if(strcmp(name,'\\methodMRFBPSTABLES')), html='mrf-BPS'; end;
%     if(strcmp(name,'\\methodMRFBPTABLES')), html='mrf-LBP'; end;
%     if(strcmp(name,'\\methodMRFLBPTABLES')), html='mrf-LBP'; end;
%     if(strcmp(name,'\\methodMRFEXPTABLES')), html='mrf-EXPANSION'; end;
%     if(strcmp(name,'\\methodMRFSWAPTABLES')), html='mrf-SWAP'; end;
% 
%     if(strcmp(name,'\\methodMRFTRWSVIEW')), html='mrf-TRWS'; end;
%     if(strcmp(name,'\\methodMRFBPSVIEW')), html='mrf-BPS'; end;
%     if(strcmp(name,'\\methodMRFBPVIEW')), html='mrf-LBP'; end;
%     if(strcmp(name,'\\methodMRFLBPVIEW')), html='mrf-LBP'; end;
%     if(strcmp(name,'\\methodMRFEXPVIEW')), html='mrf-EXPANSION'; end;
%     if(strcmp(name,'\\methodMRFSWAPVIEW')), html='mrf-SWAP'; end;
% 
%     %Native Sovers
%     if(strcmp(name,'\\methodSA')), html='SA'; end;
%     if(strcmp(name,'\\methodFASTPD')), html='FastPD'; end;
%     if(strcmp(name,'\\methodOtten')), html='BRAOBB'; end;
%     if(strcmp(name,'\\methodMCA')), html='MCA'; end;
%     if(strcmp(name,'\\methodMCA-fdo')), html='MCA-fdo'; end;
%     if(strcmp(name,'\\methodMCA-6h')), html='MCA (6h)'; end;
%     if(strcmp(name,'\\methodMCR')), html='MCR'; end;
%     if(strcmp(name,'\\methodMAXCUT')), html='MCBC'; end;
%     if(strcmp(name,'\\methodQPBO')), html='QPBO'; end;
%     if(strcmp(name,'\\methodTRWS')), html='TRWS'; end;
%     if(strcmp(name,'\\methodBPS')), html='BPS'; end;
%     if(strcmp(name,'\\methodEXP')), html='EXPANSION'; end;
%     if(strcmp(name,'\\methodSWAP')), html='SWAP'; end;
%     if(strcmp(name,'\\methodAFUSION')), html='FUSION'; end;
% 
%     if(strcmp(name,'\\methodTRWSTL')), html='TRWS'; end;
%     if(strcmp(name,'\\methodBPSTL')), html='BPS'; end;
%     if(strcmp(name,'\\methodEXPTL')), html='EXPANSION'; end;
%     if(strcmp(name,'\\methodSWAPTL')), html='SWAP'; end;
%     if(strcmp(name,'\\methodFUSION')), html='FUSION'; end;
% 
% 
%     if(strcmp(name,'\\methodTRWSTABLES')), html='TRWS'; end;
%     if(strcmp(name,'\\methodBPSTABLES')), html='BPS'; end;
%     if(strcmp(name,'\\methodEXPTABLES')), html='EXPANSION'; end;
%     if(strcmp(name,'\\methodSWAPTABLES')), html='SWAP'; end;
% 
%     if(strcmp(name,'\\methodTRWSVIEW')), html='TRWS'; end;
%     if(strcmp(name,'\\methodBPSVIEW')), html='BPS'; end;
%     if(strcmp(name,'\\methodEXPVIEW')), html='EXPANSION'; end;
%     if(strcmp(name,'\\methodSWAPVIEW')), html='SWAP'; end;
%     if(strcmp(name,'\\methodTRWSLTLF')), html='TRWS-LF2'; end;
%     if(strcmp(name,'\\methodTRWSLF')), html='TRWS-LF2'; end;
% 
% end


%% Write short HTML table to file
function saveShortHTMLTable(data, file, algs)
    data.mesurenames
    fid = fopen(file, 'w'); 
    fprintf(fid,['<table>\n']);
    text = ['<tr>\n' ,...
             '<td><b>', sprintf('%20s','algorithm'),'</b></td> ',...
             '<td><b>', sprintf('%13s','mean run time'),'</b></td> ',...
             '<td><b>', sprintf('%13s','mean value'),'</b></td> ',...
             '<td><b>', sprintf('%13s','mean bound'),'</b></td> ',...
             '<td><b>', sprintf('%8s','best'),'</b></td> ',...
             '<td><b>', sprintf('%8s','ver. opt'), '</b></td>'];  
    for i=1:numel(data.mesurenames)
        text =[text,'<td><b>', sprintf('%15s',data.mesurenames{i}),'</b></td> '];
    end
    text =[text,' </tr>'];  
    fprintf(fid,[text,'\n']);
    for a =1:numel(algs)
        info = algInfo(algs{a});
        if(max(abs(data.MVE))<10)
            form ='% 10.4f';
        else
            form ='% 10.2f';
        end
        if(0==1)
            N = size(data.T,2);
            text = [ '<tr>' ,...
                     '<td>', sprintf('%20s',info.name),'</td> ',...
                     '<td align="right">', sprintf('%13s',num2str(data.MT(a),'% 10.2f')),' sec</td> ', ...
                     '<td align="right">', sprintf('%13s',num2str(data.MVE(a),form)),'</td> ', ...
                     '<td align="right">', sprintf('%13s',num2str(data.MB(a),form)),'</td> ', ...
                     '<td align="right">', sprintf('%8s',num2str(floor(data.best(a)*N+0.01))),'/',num2str(N),'</td> ', ...
                     '<td align="right">', sprintf('%8s',num2str(floor(data.opt(a)*N+0.01))),'/',num2str(N),'</td> '];     
        else
            text = [ '<tr>\n' ,...
                     '<td>', sprintf('%20s',info.name),'</td> ',...
                     '<td align="right">', sprintf('%13s',num2str(data.MT(a),'% 10.2f')),' sec</td> ', ...
                     '<td align="right">', sprintf('%13s',num2str(data.MVE(a),form)),'</td> ', ...
                     '<td align="right">', sprintf('%13s',num2str(data.MB(a),form)),'</td> ', ...
                     '<td align="right">', sprintf('%8s',num2str(data.best(a)*100,'% 3.2f')),'</td> ', ...
                     '<td align="right">', sprintf('%8s',num2str(data.opt(a)*100,'% 3.2f')),'</td> ']; 
        end
        for i=1:numel(data.mesurenames)
            text =[text,'<td align="right">',sprintf('%13s',num2str(mean(data.M(a,:,i)),'% 8.4f')),'</td> '];
        end
        text =[text,'</tr> ']; 
        fprintf(fid,[text,'\n']); 
    end
    fprintf(fid,['</table>']);
    fclose(fid);
end


%% Write longe HTML table to file
function saveLargeHTMLTable(data, file, algs,names,mask) 
    fid = fopen(file, 'w'); 
    fprintf(fid,'<table>\n');

    table = '<tr><td>&nbsp;</td><td>&nbsp;</td>';
    for i=1:numel(algs)
        if(mask(i)) 
            info = algInfo(algs{i});
            table=[table,'<td><b>',info.name, '</b></td>'];
        end;
    end
   
    fprintf(fid,[table,'</tr>\n']);
    
    BV = (data.VE-ones(size(data.VE,1),1)*min(data.VE))<10^-5;
    BB = (ones(size(data.B,1),1)*max(data.B)-data.B)<10^-5;   
      
    for m=1:size(data.V,2) 
        if(max(abs(data.V(:,m)))<10)
            form ='% 10.4f';
        else
            form ='% 10.2f';
        end
  
        table = ['<tr class="line"><td><div align="left">',strrep(names{m},'_','-'),'</div></td><td><div align="left"> value </div></td>'];
        for a=1:numel(algs)
            if(mask(a))
                if(BV(a,m)) 
                    table=[table,'<td><b> ',num2str(data.VE(a,m),form),'</b></td>'];
                else
                    table=[table,'<td> ',num2str(data.VE(a,m),form),'</td>'];
                end
            end
        end
        fprintf(fid,[table,'<tr>\n']); 
        
        table = ['<tr class="noline"><td>&nbsp;</td><td><div align="left"> bound </div></td>'];
        for a=1:numel(algs) 
            if(mask(a))
                if(BB(a,m))
                    table=[table,'<td><b> ',num2str(data.B(a,m),form),'</b></td>'];
                else
                    table=[table,'<td> ',num2str(data.B(a,m),form),'</td>'];
                end
            end
        end
        fprintf(fid,[table,'</tr>\n']);
       
        table = ['<tr><td>&nbsp</td><td><div align="left"> runtime </div></td>'];
        for a=1:numel(algs)
            if(mask(a))
            table=[table,'<td> ',num2str(data.T(a,m),'%4.2f'),'</td>']; 
            end
        end
        fprintf(fid,[table,'</tr>\n']);
    end
    
    if(max(abs(data.MV))<10)
        form ='% 10.4f';
    else
        form ='% 10.2f';
    end
  
    %Mean Energy
    table=['<tr class="line"><td>&nbsp;</td><td><div align="left" style="white-space: nowrap;"><b>mean energy</b></div></td> '];
    for a=1:numel(algs) 
        if(mask(a))
            table=[table,'<td> ',num2str(data.MV(a),form),'</td>'];
        end;
    end
    fprintf(fid,[table,'</tr>\n']); 
    
    %Mean Bound 
    table=['<tr class="line"><td>&nbsp;</td><td><div align="left" style="white-space: nowrap;"><b>mean bound</b></div></td>'];
    for a=1:numel(algs)
        if(mask(a))
            table=[table,'<td> ',num2str(data.MB(a),form),'</td>'];
        end;
    end
    fprintf(fid,[table,'</tr>\n']);
    
    %Mean Runtime 
    table=['<tr class="line"><td>&nbsp;</td><td><div align="left" style="white-space: nowrap;"><b>mean runtime</b></div></td>'];
    for a=1:numel(algs)
        if(mask(a))
            table=[table,'<td> &nbsp;',num2str(data.MT(a),'%4.2f'),'</td>'];
        end;
    end
    fprintf(fid,[table,'</tr>\n']);
    
    %Precentage best value 
    table=['<tr class="line"><td>&nbsp;</td><td><div align="left" style="white-space: nowrap;"><b>best value</b></div></td> '];
    for a=1:numel(algs)
        if(mask(a))
            table=[table,'<td> ',num2str(data.best(a)*100,'%4.2f'),'</td>'];
        end;
    end
    fprintf(fid,[table,'<tr>\n']);
    

     %Precentage best bound 
    table=['<tr class="line"><td>&nbsp;</td><td><div align="left" style="white-space: nowrap;"><b>best bound</b></div></td> '];
    for a=1:numel(algs)
        if(mask(a))
            table=[table,'<td> ',num2str(data.bestB(a)*100,'%4.2f'),'</td>'];
        end;
    end
    fprintf(fid,[table,'</tr>\n']);
    
    %Precentage guranteed optimum 
    table=['<tr class="line"><td>&nbsp;</td><td><div align="left" style="white-space: nowrap;"><b>verified opt<b></div></td> '];
    for a=1:numel(algs)
        if(mask(a))
            table=[table,'<td> ',num2str(data.opt(a)*100,'%4.2f'),'</td>'];
        end
    end
    fprintf(fid,[table,'</tr>\n']);
    
    fclose(fid);
      
end


%% save php-instance file
function savePHPInstances(phpinstancepath,dataset,names,res,mask,algs) 
    if(exist(phpinstancepath,'dir')==0),                                       
        mkdir(phpinstancepath); 
    end;  
    fid = fopen([phpinstancepath,dataset,'.php'], 'w');
    fprintf(fid,'<?php\n');
    %instaces names
    fprintf(fid,'$instances = array(');
    fprintf(fid,['"',names{1},'"']);
    for i=2:numel(names)
       fprintf(fid,[',"',names{i},'"']); 
    end
    fprintf(fid,');\n');
    %upper cut up
     fprintf(fid,'$uppercutup = array(');
    for i=1:numel(names)
        V=[];
        for a=1:numel(mask)
            if(mask(a)==0),                             continue; end; 
            if(sum(isnan(res.(algs{a}).times{i}))>0),  continue; end; 
            if(sum(isnan(res.(algs{a}).values{i}))>0), continue; end; 
            if(sum(isnan(res.(algs{a}).bounds{i}))>0), continue; end;    
            V=[V,res.(algs{a}).values{i}(res.(algs{a}).values{i}<10^30)'];
        end
        if(i==1)
            fprintf(fid,['',num2str(quantile(V,0.9)),'']); 
        else
            fprintf(fid,[',',num2str(quantile(V,0.9)),'']); 
        end
    end
    fprintf(fid,');\n');
    
    %lower cut up
    fprintf(fid,'$lowercutup = array(');
    for i=1:numel(names)
        B=[];
        V=[];
        for a=1:numel(mask)
            if(mask(a)==0),                             continue; end; 
            if(sum(isnan(res.(algs{a}).times{i}))>0),  continue; end; 
            if(sum(isnan(res.(algs{a}).values{i}))>0), continue; end; 
            if(sum(isnan(res.(algs{a}).bounds{i}))>0), continue; end; 
            V=[V,res.(algs{a}).values{i}(res.(algs{a}).values{i}< 10^30)'];
            B=[B,res.(algs{a}).bounds{i}(res.(algs{a}).bounds{i}>-10^30)'];
        end
        B=[B,min(V)];
        if(i==1)
            fprintf(fid,['',num2str(quantile(B,0.1)),'']); 
        else
            fprintf(fid,[',',num2str(quantile(B,0.1)),'']); 
        end
    end
    fprintf(fid,');\n');
    
    fprintf(fid,'?>'); 
    fclose(fid); 
end


%% save json-data
function saveJSON(res,algs, names,mask, dataset, jsonpath, in) 
    if(exist(jsonpath,'dir')==0),                                       
        mkdir(jsonpath); 
    end;  
     if(exist([jsonpath,dataset],'dir')==0),                                       
        mkdir([jsonpath,dataset]); 
    end;  
    
    fidF = fopen([jsonpath,dataset,'/',names{in},'-full.json'], 'w'); 
    fidR = fopen([jsonpath,dataset,'/',names{in},'-reduced.json'], 'w'); 
    fidRel = fopen([jsonpath,dataset,'/',names{in},'-related.json'], 'w'); 
    
 
    fprintf(fidF,'{\n');
    fprintf(fidR,'{\n');
    fprintf(fidRel,'[\n');
       
    first =true;  
    relfirst =true;
    for a=1:numel(mask)
        if(mask(a)==0),                             continue; end; 
        if(sum(isnan(res.(algs{a}).times{in}))>0),  continue; end; 
        if(sum(isnan(res.(algs{a}).values{in}))>0), continue; end; 
        if(sum(isnan(res.(algs{a}).bounds{in}))>0), continue; end; 
      
        info = algInfo(algs{a});
        name = info.name;
        
        T = res.(algs{a}).times{in};
        for i=2:numel(T)
            T(i) = T(i-1) + T(i);
        end
        
        %% Write full data
        if(1==1)
            if(~first)
                fprintf(fidF,[',\n']); 
                fprintf(fidR,[',\n']); 
            end
            first=false;

            fprintf(fidF,['   "',name,'" : {\n']);
            fprintf(fidF,['      "label" : "',name,'",\n']);
            fprintf(fidF, '      "data" : [');
            if(isinf(res.(algs{a}).values{in}(1)))
                fprintf(fidF,['[',num2str(T(1),'%10.2f'),',"',num2str(T(1),'%10.2f'),'"]']); 
            else
                fprintf(fidF,['[',num2str(T(1),'%10.2f'),',',num2str(res.(algs{a}).values{in}(1),'%10.2f'),']']);   
            end
            for i=floor(2:max(1,numel(res.(algs{a}).times{in})/1000):numel(res.(algs{a}).times{in}))
                if(isinf(res.(algs{a}).values{in}(i)))
                    fprintf(fidF,[',[',num2str(T(i),'%10.2f'),',"',num2str(res.(algs{a}).values{in}(i),'%10.2f'),'"]']);
                else
                    fprintf(fidF,[',[',num2str(T(i),'%10.2f'),',',num2str(res.(algs{a}).values{in}(i),'%10.2f'),']']);  
                end
            end
            if(isinf(res.(algs{a}).values{in}(numel(res.(algs{a}).times{in}))))
                fprintf(fidF,['[',num2str(T(numel(T)),'%10.2f'),',"',num2str(res.(algs{a}).values{in}(numel(T)),'%10.2f'),'"]']); 
            else
                fprintf(fidF,['[',num2str(T(numel(T)),'%10.2f'),',',num2str(res.(algs{a}).values{in}(numel(T)),'%10.2f'),']']);   
            end
            fprintf(fidF,']\n');
            fprintf(fidF,'   }');
            if(max(res.(algs{a}).bounds{in})>-1e30)
                fprintf(fidF,[',\n   "',name,' bound" : {\n']);
                fprintf(fidF,['      "label" : "',name,' bound",\n']);
                fprintf(fidF, '      "data" : ['); 
                if(isinf(res.(algs{a}).bounds{in}(1)))
                    fprintf(fidF,['[',num2str(T(1),'%10.2f'),',"',num2str(res.(algs{a}).bounds{in}(1),'%10.2f'),'"]']);  
                else
                    fprintf(fidF,['[',num2str(T(1),'%10.2f'),',',num2str(res.(algs{a}).bounds{in}(1),'%10.2f'),']']); 
                end
                for i=2:floor(2:max(1,numel(T)/1000):numel(T))
                    if(isinf(res.(algs{a}).bounds{in}(i)))          
                        fprintf(fidF,[',[',num2str(T(i),'%10.2f'),',"',num2str(res.(algs{a}).bounds{in}(i),'%10.2f'),'"]']);
                    else
                        fprintf(fidF,[',[',num2str(T(i),'%10.2f'),',',num2str(res.(algs{a}).bounds{in}(i),'%10.2f'),']']);  
                    end
                end
                if(isinf(res.(algs{a}).bounds{in}(numel(T))))
                    fprintf(fidF,['[',num2str(T(numel(T)),'%10.2f'),',"',num2str(res.(algs{a}).bounds{in}(numel(T)),'%10.2f'),'"]']);  
                else
                    fprintf(fidF,['[',num2str(T(numel(T)),'%10.2f'),',',num2str(res.(algs{a}).bounds{in}(numel(T)),'%10.2f'),']']); 
                end
                fprintf(fidF,']\n');
                fprintf(fidF,'   }');      
            end
        end 
        %% Write Reduced Data
        cV=1;
        cB=1;
        V=zeros(1,numel(T));
        B=zeros(1,numel(T));
        TV=zeros(1,numel(T));
        TB=zeros(1,numel(T));
        V(1)  = res.(algs{a}).values{in}(1);
        TV(1) = T(1);
        B(1)  = res.(algs{a}).bounds{in}(1);
        TB(1) = T(1); 
        for i=2:numel(T)-1
            if(res.(algs{a}).values{in}(i)<V(cV))
                cV = cV+1;
                V(cV) = res.(algs{a}).values{in}(i);
                TV(cV) = T(i);
            end
            if(res.(algs{a}).bounds{in}(i)>B(cB))
                cB = cB+1;
                B(cB) = res.(algs{a}).bounds{in}(i);
                TB(cB) = T(i);
            end
        end    
        cV = cV+1;
        V(cV) = res.(algs{a}).values{in}(end);
        TV(cV) = T(end);
        cB = cB+1;
        B(cB) = res.(algs{a}).bounds{in}(end);
        TB(cB) = T(end);
        
        if(cV>102)
            ind = [1,floor(2:(cV-2)/98.0:cV-1),cV];
            cV=numel(ind);
            V=V(ind);
            TV=TV(ind);
        end
        if(cB>102)
            ind = [1,floor(2:(cB-2)/98.0:cB-1),cB];
            cB=numel(ind);
            B=B(ind);
            TB=TB(ind);
        end
        
          
        fprintf(fidR,['   "',name,'" : {\n']);
        fprintf(fidR,['      "label" : "',name,'",\n']);
        fprintf(fidR, '      "data" : [');
        if(isinf(V(1)))
            fprintf(fidR,['[',num2str(TV(1),'%10.2f'),',"',num2str(V(1),'%10.2f'),'"]']); 
        else
            fprintf(fidR,['[',num2str(TV(1),'%10.2f'),',',num2str(V(1),'%10.2f'),']']);   
        end
        for i=2:cV
            fprintf(fidR,[',[',num2str(TV(i),'%10.2f'),',',num2str(V(i),'%10.2f'),']']);  
        end
        fprintf(fidR,']\n');
        fprintf(fidR,'   }');
        if(max(B(1:cB))>-1e30)
            fprintf(fidR,[',\n   "',name,' bound" : {\n']);
            fprintf(fidR,['      "label" : "',name,' bound",\n']);
            fprintf(fidR, '      "data" : ['); 
            if(isinf(res.(algs{a}).bounds{in}(1)))
                fprintf(fidR,['[',num2str(TB(1),'%10.2f'),',"',num2str(B(1),'%10.2f'),'"]']);  
            else
                fprintf(fidR,['[',num2str(TB(1),'%10.2f'),',',num2str(B(1),'%10.2f'),']']); 
            end
            for i=2:cB
                fprintf(fidR,[',[',num2str(TB(i),'%10.2f'),',',num2str(B(i),'%10.2f'),']']);  
            end
            fprintf(fidR,']\n');
            fprintf(fidR,'   }');    
            
            % Entry in related dataset file
            if(~relfirst)
                fprintf(fidRel,[',']); 
            end
            relfirst=false; 
            fprintf(fidRel,' {\n');
            fprintf(fidRel,['   "label": "',name,' ",\n']);
            fprintf(fidRel,'   "datasets": [\n');
            fprintf(fidRel,['     "',name,'",\n']);
            fprintf(fidRel,['     "',name,' bound"\n']);
            fprintf(fidRel,'   ]\n');
            fprintf(fidRel,'  }\n');           
        end
        
        %%
    end
    fprintf(fidF,'\n}'); 
    fprintf(fidR,'\n}');   
    fprintf(fidRel,'\n]');   
    fclose(fidR);   
    fclose(fidF);
    fclose(fidRel); 
end
