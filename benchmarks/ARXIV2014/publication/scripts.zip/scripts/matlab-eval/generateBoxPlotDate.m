function generateBoxPlotDate(model,outpath)
    set_gmb_paths;
    [res,names]       = evaluation_load(model,0);
    algs              = fieldnames(res); 
    numberOfInstances = numel(res.(algs{1}).times);
    
    V             = zeros(numel(algs),numberOfInstances);
    B             = zeros(numel(algs),numberOfInstances);
    T             = zeros(numel(algs),numberOfInstances);
    
    
    for a=1:numel(algs)
       alg = algs{a};
       %algs2 = alg2name( strrep(alg,'_','-'));
       if(0)%strcmp(algs2,''))
                T(a,:)  = 10^10;
                V(a,:)  = 10^40;
                B(a,:)  =-10^40;    
       else
            for i=1:numberOfInstances
                T(a,i)  = max(res.(alg).times{i});
                V(a,i)  = min(min(res.(alg).values{i}),10^40);
                B(a,i)  = max(max(res.(alg).bounds{i}),-10^40);
            end
       end
    end
   % best = mean(abs(V-ones(numel(algs),1)*min(V)) ./ abs( 10^-5 + ones(numel(algs),1)*min(V)) < 10^-6,2) ;  
    
    best = mean( (abs(V-ones(numel(algs),1)*min(V))< 10^-5) | (abs(V-ones(numel(algs),1)*min(V)) ./ (abs(ones(numel(algs),1)*min(V))+1)< 10^-10) ,2);     
    opt  = mean( (abs(V-B)< 10^-5) | (abs(V-B)./(abs(V)+1)< 10^-10),2);
  
    mkdir([outpath,'/',model]);
   
    
    
    inda = [];
    for a=1:numel(algs) 
        alg = algs{a}; 
        alg = strrep(alg,'_','-');
        if( isnan(mean(T(a,:))) )
            disp(['skip ',alg, '(incomplete)']);
            continue;
        end    
        inda = [inda,a];
    end
   
        
    O = min(V(inda,:),[],1);
    S = quantile(mean(V(inda,:)-ones(numel(inda),1)*O,2),0.8)+1;
    mean(V(inda,:)-ones(numel(inda),1)*O,2)
    
    f = fopen([outpath,'/',model,'/base.dat'], 'w');
    fprintf(f, '%f,%f,%d', O,S, numberOfInstances);
    fclose(f);
   
    model_energy_normalization;
    for a=1:numel(algs)
        alg = algs{a}; 
        alg = strrep(alg,'_','-'); 
        if( isnan(mean(T(a,:))) )
            disp(['skip ',alg, '(incomplete)']);
            continue;
        end
        mV = mean(V(a,:));
        mB = mean(B(a,:)); 
        mT = mean(T(a,:));
        mO = mean(O);
        
        
        %pv = 1/6*log10(mean((V(a,:)-O))*100+1)/log10(100) + 0.000001;
        %pb = 1/4*log10(mean((O-B(a,:)))*100+1)/log10(100) + 0.000001;
        % pt = log10(mean(T(a,:))*10+1)/log10(40000+1);
        
        nV =  EN.(strrep(model,'-','_'));
        
        if(mV-mO<nV)
            pv = 0.5 *(mV-mO) / nV; 
        elseif(mV-mO<10*nV)
            pv = 0.5 + 0.5 *(mV-mO-nV) / (9*nV); 
        else
            pv = 1.1;
        end
        
        if(mO-mB<nV)
            pb = 0.5 *(mO-mB) / nV; 
        elseif(mO-mB<10*nV)
            pb = 0.5 + 0.5 *(mO-mB-nV) / (9*nV);
        elseif(mB<-10^20)
            pb = 10000;
        else
            pb = 1.1;
        end
       
        if(mT<1)
           pt=mT*0.333;   
        elseif (mT<60) 
            pt=0.333 + (mT-1)/59*0.333;       
        elseif (mT<3600)
            pt=0.666 + (mT-60)/3540*0.333;        
        else
           pt=1.1;  
        end
      
        
        info = algInfo(alg); 
        if(strcmp(info.name,'%')==0)
           disp(['*** Add : ',alg]);           
           f = fopen([outpath,'/',model,'/',info.name,'.dat'], 'w');
            %fprintf(f, '%f,%f,%f,%f,%f', min(100,(sum(V(a,:))-O)/S), min(100,(O-sum(B(a,:)))/S), sum(T(a,:))/3600,best(a),opt(a));
            fprintf(f, '%f,%f,%f,%f,%f', pv, ...
                                         pb, ...
                                         pt,...
                                         best(a),...
                                         opt(a));
            fclose(f);
        
            string = sprintf('%s: %f,%f,%f,%f,%f', alg,...
                                     pv, ...
                                     pb, ...
                                     pt,...
                                     best(a),...
                                     opt(a));
            disp(string)
        else
           disp(['*** Skip: ',alg]);
        end; 
          
      
    end
end