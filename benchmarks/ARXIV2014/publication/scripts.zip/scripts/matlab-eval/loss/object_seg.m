

% Evaluation for dtf_chinesechar
%
% Author:  Joerg H Kappes (kappes -at- {math.uni-heidelberg.de})
% Date:    25th February 2014


% load ground-truth and superpixel information
load(fullfile(gmb_datapath,'object-seg.mat'));


for a=1:numel(fieldnames(res))
	fn = fieldnames(res);
    alg = fn{a};
	for i=1:numberOfInstances
        modelname = names{i};
		x = reshape(res.(alg).states{i}(:),213,320)+1;
        gt = L{i};
        M  = (gt>0);
        
        if(numel(gt)~=numel(x))
            res.(alg).PA{i} = nan;
        else
            res.(alg).PA{i} = sum(sum((x==gt).*M))./sum(M(:));
        end
	end
end
