
% Evaluation for inclusion
%
% Author:  Joerg H Kappes (kappes -at- {math.uni-heidelberg.de})
% Date:    28th March 2014


    gt = dir([gmb_datapath,'mrf-inpainting/*.png']);
    for a=1:numel(fieldnames(res))
       fn = fieldnames(res);
       alg = fn{a};
       for i=1:numberOfInstances
            I = imread([gmb_datapath,'mrf-inpainting/',gt(i).name])';
            res.(alg).HD{i} =  mean(abs(double(res.(alg).states{i}) - double(I(:))));  
       end       
    end