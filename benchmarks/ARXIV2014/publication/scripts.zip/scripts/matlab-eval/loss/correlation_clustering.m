% Evaluation for correlation clustering
%
% Author:  Joerg H Kappes (kappes -at- {math.uni-heidelberg.de})
% Date:    28th March 2014

gt_img = dir([gmb_datapath,'correlation-clustering/GroundTruth/*.mat']);
gt_imsegs = dir([gmb_datapath,'correlation-clustering/superpixels/*.mat']);

for a=1:numel(fieldnames(res))
    fn = fieldnames(res);
    alg = fn{a};
    sumPRI = 0;
    sumGCE = 0;
    sumVOI = 0;
    sumSCO = 0;
    sumBDE = 0;
    for i=1:numberOfInstances
        load([gmb_datapath,'correlation-clustering/GroundTruth/',gt_img(i).name], 'gt_seg');
        load([gmb_datapath,'correlation-clustering/superpixels/',gt_imsegs(i).name], 'imsegs');
        if(~isnan(res.(alg).states{i}(1)))
            partitions = double(res.(alg).states{i}(imsegs.segimage));
        else
            partitions = zeros(1,1);
        end
     
        if numel(gt_seg) == numel(partitions)
            m = partitionEvaluation({{gt_seg}}, {partitions});
            res.(alg).VI{i}=m(1,1);
            res.(alg).RI{i}=m(1,2);
        else
            res.(alg).VI{i}=nan;
            res.(alg).RI{i}=nan;   
        end
    end
end