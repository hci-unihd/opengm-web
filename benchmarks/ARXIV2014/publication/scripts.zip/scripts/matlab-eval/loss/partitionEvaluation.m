function m = partitionEvaluation(GT, P)
    N = numel(P);
    m = zeros(N,2);
    assert(numel(GT)==N);

    for n=1:N
        for i=1:numel(GT{n})
            % variation_of_information and rand_index are public available 
            % https://github.com/bjoern-andres/partition-comparison
            
            m(n,1) = m(n,1) + variation_of_information(GT{n}{i}+1,P{n}+1)*log2(10)/log(10);
            m(n,2) = m(n,2) + rand_index(GT{n}{i}+1,P{n}+1);
        end
        m(n,1) = m(n,1)/numel(GT{n});
        m(n,2) = m(n,2)/numel(GT{n});
    end    
end