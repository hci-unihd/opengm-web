

% Evaluation for inclusion
%
% Author:  Joerg H Kappes (kappes -at- {math.uni-heidelberg.de})
% Date:    25th February 2014



I = imread(fullfile(gmb_datapath,'inclusion/ring.png'));
L = I(:,:,1)/64;

for a=1:numel(fieldnames(res))
	fn = fieldnames(res);
    alg = fn{a};
	for i=1:numberOfInstances
        modelname = names{i};
        if(1024~=numel(res.(alg).states{i}(:)))
            res.(alg).PA{i} = nan;
        else
            x = reshape(res.(alg).states{i}(:),32,32)+1;
            res.(alg).PA{i} = mean(x(:)==L(:));
        end
	end
end
