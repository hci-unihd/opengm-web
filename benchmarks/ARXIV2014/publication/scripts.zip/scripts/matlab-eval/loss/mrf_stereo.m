
% Evaluation for inclusion
%
% Author:  Joerg H Kappes (kappes -at- {math.uni-heidelberg.de})
% Date:    28th March 2014

    gt = dir([gmb_datapath,'mrf-stereo/*.png']);
    for a=1:numel(fieldnames(res))
       fn = fieldnames(res);
       alg = fn{a};
       for i=1:numberOfInstances
            I = imread([gmb_datapath,'mrf-stereo/',gt(i).name])';
            res.(alg).PA2{i} =  mean( abs(double(res.(alg).states{i}) - double(I(:))) <= 2);
            res.(alg).PA4{i} =  mean( abs(double(res.(alg).states{i}) - double(I(:))) <= 4);
            res.(alg).HammingDistance{i} =  mean(abs(double(res.(alg).states{i}) - double(I(:))));
       end       
    end
