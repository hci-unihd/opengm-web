

% Evaluation for Geometric Labelling task (with 7 labels)
%
% Author: Dhruv Batra (dbatra -at- {ttic.edu,vt.edu})
%         Joerg H Kappes (kappes -at- {math.uni-heidelberg.de})
% Date: 10th August 2013

% load ground-truth and superpixel information
load(fullfile(gmb_datapath,'geo-surf/allimsegs.mat'));

for a=1:numel(fieldnames(res))
	fn = fieldnames(res);
	alg = fn{a};
	for i=1:numberOfInstances
        modelname = names{i};
        N = str2num(modelname(3:end));
		x = res.(alg).states{i}(:) + 1; 
        if(numel(imsegs(N).labels(:))~=numel(x))
            res.(alg).PA{i} = nan;
        else
            pa = sum((x(:)==imsegs(N).labels(:)).*imsegs(N).npixels(:)) / sum(imsegs(N).npixels);
            res.(alg).PA{i} = pa;
        end
	end
end
