
% Evaluation for inclusion
%
% Author:  Joerg H Kappes (kappes -at- {math.uni-heidelberg.de})
% Date:    28th March 2014

gt = dir([gmb_datapath,'matching/*.mat']);
    for a=1:numel(fieldnames(res))
       fn = fieldnames(res);
       alg = fn{a};
       for i=1:numberOfInstances
            sol = load([gmb_datapath,'matching/',gt(i).name]);
            if (numel(sol.correct_labeling) == numel(res.(alg).states{i}) )
                diff = sol.tp(1:2,sol.correct_labeling+1) - sol.tp(1:2,double(res.(alg).states{i})+1);
                res.(alg).MeanPositionError{i} = mean(sqrt(sum(diff.^2)));
            else
                res.(alg).MeanPositionError{i} = nan;  
            end
       end       
    end

