

% Evaluation for dtf_chinesechar
%
% Author:  Joerg H Kappes (kappes -at- {math.uni-heidelberg.de})
% Date:    25th February 2014


% load ground-truth and superpixel information
load(fullfile(gmb_datapath,'dtf-chinesechar/dtf-chinesechar.mat'));


for a=1:numel(fieldnames(res))
	fn = fieldnames(res);
    alg = fn{a};
	for i=1:numberOfInstances
        modelname = names{i};
		x = res.(alg).states{i}(:);
        gt = image{i}';
        M  = (noisyImage{i}>0& noisyImage{i}<1)';
        
        if(numel(gt)~=numel(x))
            res.(alg).PA{i} = nan;
        else
            res.(alg).PA{i} = sum((x==gt(:)).*M(:))./sum(M(:));
        end
	end
end
