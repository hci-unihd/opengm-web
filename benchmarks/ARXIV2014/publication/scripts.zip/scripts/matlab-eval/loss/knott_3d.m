
% Evaluation for inclusion
%
% Author:  Joerg H Kappes (kappes -at- {math.uni-heidelberg.de})
% Date:    25th February 2014

sp_path               = [gmb_datapath,'/knott-3d/'];
gt_path               = [gmb_datapath,'/knott-3d/'];

for i=1:numberOfInstances
    modelname = names{i};
    modelnumber = modelname(end-2:end);
    supervoxel_file_name = sprintf('%s/sv_%s.h5', sp_path, modelnumber);
    gt_file_name = sprintf('%s/gt_%s.h5', gt_path, modelnumber);
    SV = uint32(h5read(supervoxel_file_name, '/sv')+1);
    GT = uint32(h5read(gt_file_name, '/gt'));
    
    for a=1:numel(fieldnames(res))
        fn = fieldnames(res);
        alg = fn{a}; 
        L = res.(alg).states{i}(:);    
        if(numel(L)<max(SV(:)))
            disp('error')
            P = uint32(SV);
        else
            P = uint32(L(SV)+1);
        end
        
        res.(alg).VI{i} = variation_of_information(GT(:),P(:))*log2(10)/log(10);
        res.(alg).RI{i} = rand_index(GT(:),P(:));
        
    end
end