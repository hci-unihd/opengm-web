

% Evaluation for DAGS semantic scene segmentation instances
%
% Author: Sebastian Nowozin <Sebastian.Nowozin@microsoft.com>
% Date: 30th October 2012

sd_data_path =  [gmb_datapath,'scene-decomposition/'];

for a=1:numel(fieldnames(res))
	fn = fieldnames(res);
	alg = fn{a};
	for i=1:numberOfInstances
        modelname = names{i};

		% Load ground truth map
		gt_image = load(sprintf('%s/%s-gt.mat', sd_data_path, modelname));
		gt_image = gt_image.gt_image;

		% Form pixel-level output
		spix=load(sprintf('%s/%s-spix.mat', sd_data_path, modelname));
		spix=spix.spix_image;
		x = res.(alg).states{i};
		x = x + 1;
        if(isnan(x(1)) || numel(x)<max(spix(:)))
            res.(alg).PixelAccuracy{i} = nan;  
        else
            M_map    = zeros(size(spix,1),size(spix,2));
            M_map(:) = uint8(x(spix(:))); 

        	% Compute pixel level correctness, between 0 (everything wrong) to 1
            % (all pixels labelled correctly).
            correct_map = double(M_map == gt_image);
            res.(alg).PixelAccuracy{i} = mean(correct_map(:));
        end
	end
end
