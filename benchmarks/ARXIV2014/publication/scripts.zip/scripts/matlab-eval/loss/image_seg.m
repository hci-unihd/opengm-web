
% Evaluation for image segmentation
%
% Author:  Joerg H Kappes (kappes -at- {math.uni-heidelberg.de})
% Date: 28th March 2014

sp_path                = [gmb_datapath,'image-seg/'];
bsd300_h5_folder_name  = [gmb_datapath,'bsd300-h5'];

%% Generate GT
disp('Load GT ...')
truth_folder_name = [bsd300_h5_folder_name '/human/color'];
segmentor_names   = dir(truth_folder_name);
GT = cell(numberOfInstances,1);
for i=1:numberOfInstances
    modelname = names{i}(1:end-4);
    files = cell(0,1);
    for j = 1:numel(segmentor_names) % loop over human segmentors
        segmentor_name = segmentor_names(j).name;
        if(exist([truth_folder_name '/' segmentor_name,'/',modelname,'.h5']))
            files{end+1}=[truth_folder_name '/' segmentor_name,'/',modelname,'.h5'];
        end
    end
    GT{i}=cell(numel(files),1);
    for j=1:numel(files)
        GT{i}{j} = h5read(files{j}, '/seg');         
    end
    assert(numel(GT{i})>0);
end
disp('done')


%% Generate partition P
P = cell(numberOfInstances,1);
for a=1:numel(fieldnames(res))
	fn = fieldnames(res);
	alg = fn{a}; 
    disp(['Load ',num2str(a),' : ',alg])
    for i=1:numberOfInstances
        modelname = names{i};
        superpixel_file_name = sprintf('%s/%s.h5', sp_path, modelname);
        T = h5read(superpixel_file_name, '/superpixel-segmentation');
        T = T(1:2:end, 1:2:end)'; 
        L = res.(alg).states{i}(:) + 1;    
        if(numel(L)<max(T(:)))
            P{i} = T;
        else
            P{i} = uint32(L(T));
        end
    end
    disp(['Eval ',num2str(a)])
    m = partitionEvaluation(GT, P);
    for i=1:numberOfInstances
        res.(alg).VI{i}=m(i,1);
        res.(alg).RI{i}=m(i,2);
    end
end